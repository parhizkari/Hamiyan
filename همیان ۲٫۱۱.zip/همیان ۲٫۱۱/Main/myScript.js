//============  THE MAIN VARIABLES AND INITIAL FILLING OF THE WEBPAGE ON LOAD  =============//



//== global variables ==
var container=document.getElementById('container');

var accounts=[], startingAmounts=[], accountLength, // saves the name of the accounts and their starting values
	classList=[],	// contains the list of "transcation classes" already defined, to select while inserting a new transaction in the book
	table,		// contains several different tables inside the forms, account & transactions input and edit
	pageToBeEdited,	// it will be used by the function:  saveEditedPage()
	myJSONData,		// the main variable (JSON DATABASE) which contains the whole data
	hslider='calc(46% - 20px)', vslider='calc(80vh - 50px)',   //saves last size of Pages related to different days ...
	totalPageNumber=1, currentPage=1, selectedPageNumShown=10,
	StartToEndVar=0,
	chartLine, chartBar, chartPieSpent, chartPieIncome;	 //variables referring to the charts, to destroy and renew them


document.getElementById("hSizeSlider").value = '46';
document.getElementById("vSizeSlider").value = '80';


document.getElementById("goToPage").value="۱\/۱";


window.location.href='#';



//=============  USE localStorage OF HTML5 TO RELOAD DATA FROM CACHE AT START  ==============//



if (window.localStorage["savedInCahe"] != 'undefined' && window.localStorage["savedInCahe"] != null) {
	//retrieves the data from the browser's cache even after the browser/tab is reopened
	myJSONData = JSON.parse(window.localStorage["savedInCahe"]);
	
	
	// re-populate the global variables required all over the program
	accountLength=myJSONData.Accounts.length;	accounts=[];	startingAmounts=[];
	for(var i=0; i<accountLength; i++){
		accounts.push(myJSONData.Accounts[i]);
		startingAmounts.push(myJSONData.StartingAmounts[i]);
	}
	
	
	// list the transactions' classNames
	classList=[];
	for (var day=0, days=myJSONData["days"].length; day<days; day++) {	//var day in myJSONData["days"]
		for (var transaction in myJSONData["days"][day]["transactions"]) {
			var className=myJSONData["days"][day]["transactions"][transaction]["class"];
			if(classList.indexOf(className)==-1){classList.push(className);}
		}
	}
	classList.sort(function(a, b){return a.localeCompare(b)});
	document.getElementById("classNameDataList").innerHTML="";
	for(var i=0, l=classList.length; i<l ; i++){
		document.getElementById("classNameDataList").innerHTML+='<option value=\"'+classList[i]+'\">';
	}
}


window.onload=function(){
	if(myJSONData){
		document.getElementById("bookName").innerHTML="<span style='color:rgb(238,232,170);'>حساب مالی: </span>"+myJSONData.BookName;
		
		selectedPageNumShown = myJSONData.daysInPageNum;
		StartToEndVar = myJSONData.start2End;
		hslider = myJSONData.hslider;
		vslider = myJSONData.vslider;
		currentPage = myJSONData.currentPage;
		
		document.getElementById("hSizeSlider").value = hslider.replace(/[^\d]*(\d+)\%.*/,"$1");
		document.getElementById("vSizeSlider").value = vslider.replace(/[^\d]*(\d+)vh.*/,"$1");
		
		fillTheBook();
		selectHowMany();
	}
}





//=============  FIND THE PRESENT DATE IN THE PERSIAN CALENDAR  ==============//



function gregorian_to_jalali(gy,gm,gd){
	g_d_m=[0,31,59,90,120,151,181,212,243,273,304,334];
	jy=(gy<=1600)?0:979;
	gy-=(gy<=1600)?621:1600;
	gy2=(gm>2)?(gy+1):gy;
	days=(365*gy) +(parseInt((gy2+3)/4)) -(parseInt((gy2+99)/100)) +(parseInt((gy2+399)/400)) -80 +gd +g_d_m[gm-1];
	jy+=33*(parseInt(days/12053)); 
	days%=12053;
	jy+=4*(parseInt(days/1461));
	days%=1461;
	jy+=parseInt((days-1)/365);
 	if(days > 365)days=(days-1)%365;
	jm=(days < 186)?1+parseInt(days/31):7+parseInt((days-186)/30);
	jd=1+((days < 186)?(days%31):((days-186)%30));
	return [jy,jm,jd];
};
var persianMonth=["","فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
var dayOfWeek=["یکشنبه","دوشنبه","سه‌شنبه", "چهارشنبه","پنجشنبه","جمعه","شنبه"];
var shortDate;
var currenDayOfWeek;
var morningAfternnon;
function persianDateTime(){
	d=new Date();
	g_y=d.getFullYear();
	g_m=d.getMonth()+1;
	g_d=d.getDate();
	currenDayOfWeek=d.getDay();
	shamsi=gregorian_to_jalali(g_y,g_m,g_d);
	H=d.getHours();
	//H=(H<10)?"0"+H:H;
	
	var morningAfternoon= 
		(H==12)  ? "ظهر" : (
			(H!=0) ? (
				(H<12) ? "صبح" : (
					(H>=20) ? "شب" :  "بعد از ظهر"
				)
			)
			: "نیمه‌شب"
		);
		
	i = d.getMinutes();
	i = (i<10) ? "0"+i : i;
	
	shortDate=shamsi[0]+"٫"+shamsi[1]+"٫"+shamsi[2]+" - "+H+":"+i;
	
	H = (H<=12)  ?  H  :  H-12;
	H = (H<10) ? "0"+H : H;
	
	return "("+shamsi[0]+"٫"+shamsi[1]+"٫"+shamsi[2]+" ساعت "+H+":"+i+" "+morningAfternnon+")";
}; // now you can use the present date by calling the function  persianDateTime()




//=================  TRANSFORM NUMBERS TO PERSIAN/ENGLISH  ==================



function toFa(textContainingEnglishNumbers){
	return textContainingEnglishNumbers.toString()
		.replace(/0/g,'۰').replace(/1/g,'۱').replace(/2/g,'۲').replace(/3/g,'۳').replace(/4/g,'۴').replace(/5/g,'۵')
		.replace(/6/g,'۶').replace(/7/g,'۷').replace(/8/g,'۸').replace(/9/g,'۹').replace(/\./g,'٫');
}
function toEn(persianNumbers){
	return Number(
		persianNumbers.toString()
			.replace(/۰/g,'0').replace(/۱/g,'1').replace(/۲/g,'2').replace(/۳/g,'3').replace(/۴/g,'4').replace(/۵/g,'5')
			.replace(/۶/g,'6').replace(/۷/g,'7').replace(/۸/g,'8').replace(/۹/g,'9').replace(/[\/٫]/g,'.')
	);
}
function numberWithSeparators(simpleNumber){
	return toFa(   toEn(simpleNumber).toString().replace(/\B(?=(\d{3})+(?!\d))/g, "٬")  );		//use either "٬" or ","
}
//alert(toFa("53 is 53 and not 78 !"));
//alert(toEn("۴۵")+2);
/*
alert(numberWithSeparators(3456789.0));
alert(numberWithSeparators(23456789.1));
alert(numberWithSeparators("۴۵۶۷۸۹/۰"));
alert(numberWithSeparators("۲۳۴۵۶۷۸۹.۰"));
alert(numberWithSeparators("۴۵۶۷۸۹/۱"));
alert(numberWithSeparators("۳۴۵۶۷۸۹.۱"));
*/




//=============  to define some keyboard shortcuts and etc ...  ==============



document.addEventListener("keydown", function(e){
	// add the shortcut "ctrl + F1" for ADD A NEW PAGE
	if (e.ctrlKey && e.keyCode === 112) { e.preventDefault(); addNewDay(); }
	// add the shortcut "ctrl + F3" to Focus to select Page umber Input
	if (e.ctrlKey && e.keyCode === 114) { e.preventDefault(); document.getElementById("goToPage").focus(); document.getElementById("goToPage").value="";}
	
	
	// add the shortcut "ctrl+down" for page change to NEXT
	if (e.ctrlKey && e.keyCode === 40) { e.preventDefault(); nextPage(); }
	// add the shortcut "ctrl+up" for page change to PREVIOUS
	if (e.ctrlKey && e.keyCode === 38) { e.preventDefault(); prevPage(); }
	
	
	// to close the popupAbout by pressing the key "Esc"
	if (e.keyCode == 27 && e.target.id == 'popupAbout') {
		window.location.href='#';
	}
});



document.onclick = function(e){
	//check if the dark backgrounds of the popups are clicked ...
	if(e.target.id == 'popupAbout'){
		window.location.href='#';
	}
}


document.getElementById("goToPage").onclick = function(){
	document.getElementById("goToPage").value="";
}
document.getElementById("goToPage").addEventListener("focusout",function(){
	document.getElementById("goToPage").value=toFa(currentPage)+"\/"+toFa(totalPageNumber);
});




//=============  Pagination  ==============



function selectHowMany(){
	document.getElementById("selectBox").value=selectedPageNumShown;
	
	if(myJSONData){
		myJSONData.currentPage = currentPage;
		myJSONData.daysInPageNum = selectedPageNumShown
		
		
		if(selectedPageNumShown=="ALL"){
			totalPageNumber=1;
			//currentPage=1;
		} else {
			totalPageNumber=(myJSONData["days"].length)?  Math.ceil(myJSONData["days"].length / selectedPageNumShown)  : 1;
			//currentPage=(StartToEndVar==0)?  1 : totalPageNumber;
			if(currentPage > totalPageNumber){
				myJSONData.currentPage = currentPage = totalPageNumber;
			}
		}
		document.getElementById("goToPage").value=toFa(currentPage)+'\/'+toFa(totalPageNumber);
		saveToCache();
		
		changePage();
	}else{
		return false;
	}
}


function nextPage(){
	myJSONData.currentPage = currentPage = (currentPage < totalPageNumber) ? currentPage+1 : totalPageNumber ;
	saveToCache();
	
	document.getElementById("goToPage").value=toFa(currentPage)+'\/'+toFa(totalPageNumber);
	
	// to show only those pages which lie in the range selected
	changePage();
}
function prevPage(){
	myJSONData.currentPage = currentPage = (currentPage > 1) ? currentPage-1 : 1 ;
	saveToCache();
	
	document.getElementById("goToPage").value=toFa(currentPage)+'\/'+toFa(totalPageNumber);
	
	// to show only those pages which lie in the range selected
	changePage();
}
document.getElementById("goToPage").onkeypress = function(ev){
	if (ev.which === 13){
		myJSONData.currentPage = currentPage = toEn(document.getElementById("goToPage").value);
		if(currentPage < 1){ myJSONData.currentPage = currentPage = 1; }
		if(currentPage > totalPageNumber){ myJSONData.currentPage = currentPage = totalPageNumber; }
		saveToCache();
		
		document.getElementById("goToPage").value=toFa(currentPage)+'\/'+toFa(totalPageNumber);
		
		// to show only those pages which lie in the range selected
		changePage();
	}
}

function changePage(){
	for(var day=1, days=myJSONData["days"].length; day<=days; day++) {
		if(!document.getElementById("Page"+day).classList.contains("hidden")){
			document.getElementById("Page"+day).classList.add("hidden");
		}
	}
	// to determine the range of days that should be shown in the current page
	if(StartToEndVar==0){		//to display the pages in reverse order, the last page at top-right of the webpage
		if(selectedPageNumShown == "ALL"){
			initialDayNum=0;
			finalDayNum=myJSONData["days"].length - 1;
		}else{
			initialDayNum=myJSONData["days"].length - currentPage*selectedPageNumShown;
			if(initialDayNum<0) initialDayNum=0;
			finalDayNum=myJSONData["days"].length - (currentPage-1)*selectedPageNumShown - 1;
		}
	}else{						//to display the pages in straight order of page numbers, the last page at bottom-left of the webpage
		if(selectedPageNumShown == "ALL"){
			initialDayNum=0;
			finalDayNum=myJSONData["days"].length - 1;
		}else{
			initialDayNum=(currentPage-1)*selectedPageNumShown;
			finalDayNum=currentPage*selectedPageNumShown - 1;
			if(finalDayNum>myJSONData["days"].length) finalDayNum=myJSONData["days"].length;
		}
	}
	
	
	/*
	// to show only those pages which lie in the correct range,
	// with correct order of appearance from start to end or the reverse (from https://stackoverflow.com/a/16925353)
	if(StartToEndVar==0){	//to display the pages in reverse order, the last page at top-right of the webpage
		container.style.transform = "scale(-1,-1)";
	}else{					//to display the pages in straight order of page numbers
		container.style.transform = "scale(1,1)";
	}
	for (var i in pagesShown) {
		if(i>=initialDayNum && i<=finalDayNum){
			document.getElementById("Page"+(Number(i)+1)).classList.remove("hidden");
		}
		
		if(StartToEndVar==0){	//to display the pages in reverse order, the last page at top-right of the webpage
			document.getElementById("Page"+(Number(i)+1)).style.transform = "scale(-1,-1)";
		}else{					//to display the pages in straight order of page numbers
			document.getElementById("Page"+(Number(i)+1)).style.transform = "scale(1,1)";
		}
	}
	*/
	for (var i in myJSONData["days"]) {
		if(i>=initialDayNum && i<=finalDayNum){
			document.getElementById("Page"+(Number(i)+1)).classList.remove("hidden");
		}
	}
}



//=================  Populate the currenDate div in main header  ==================//



persianDateTime();
document.getElementById("currenDate").innerHTML=toFa(dayOfWeek[currenDayOfWeek]+" "+shamsi[0]+"٫"+shamsi[1]+"٫"+shamsi[2]);



//=================  BUILD A WHOLE NEW WALLET  ==================//



function newWallet() {
	if(myJSONData){
		if(!confirm('با ایجاد پرونده‌ی مالی جدید اطلاعات پرونده‌ی قبلی پاک می‌شوند، آیا ادامه می‌دهید؟')){
			return false;
		}
	}
	window.location.href='#popupNewBook';
	setTimeout(function(){
		document.getElementById("bookTitle").focus();
	}, 500);
}
function addNewAccount() {
	if(document.getElementById("accountDefinitionContainer").innerHTML===""){
		document.getElementById("accountDefinitionContainer").innerHTML=
			'<table align="center" cellspacing=0 cellpadding=0 id="accountTable" style="text-align:center;" border=0>'
				+'<tr style="font-size:80%;">'
					+'<th>عنوان حساب</th>'
					+'<th>موجودی ابتدایی (به تومان)</th>'
				+'</tr>'
			+'</table>';
	}
	table=document.getElementById("accountTable");
	var table_len=(table.rows.length);
	var row = table.insertRow(table_len).outerHTML=
		'<tr id="accountRow'+table_len+'">'
			+'<td><input type="text" id="accountTitle'+table_len+'" size=30></td>'
			+'<td><input type="text" id="startingAmount'+table_len+'" size=20></td>'
			+'<td  id="accountEdit'+table_len+'" style="vertical-align: middle;">'
				+'<table align="center" cellspacing=0 cellpadding=0  style="text-align:center;" border=0>'
					+'<tr>'
						+'<td  rowspan="2"><input type="submit" value="" class="myButton" style="background:url(Main/images/close.png) 20px 20px/20px 20px; border: solid 0px #000000; width:20px; height:20px; margin-bottom:5px;" onclick="delete_accountRow('+table_len+')" title="حذف حساب"/></td>'
						+'<td><input type="submit" value="" class="myButton" style="background:url(Main/images/up.png) 0px 10px/10px 10px no-repeat; border: solid 0px #000000; width:10px; height:20px;" onclick="moveUpAccount('+table_len+')" title="انتقال به یک ردیف بالاتر"/></td>'
					+'</tr>'
					+'<tr><td><input type="submit" value="" class="myButton" style="background:url(Main/images/down.png) 0px 0px/10px 10px no-repeat; border: solid 0px #000000; width:10px; height:10px;" onclick="moveDownAccount('+table_len+')" title="انتقال به یک ردیف پایین‌تر"/></td></tr>'
				+'</table>'
			+'</td>'
		+'</tr>';
		
	setTimeout(function(){
		document.getElementById("accountTitle"+table_len).focus();
	}, 500);
}
function delete_accountRow(num){
	if(!confirm('با ادامه‌ی این کار، اطلاعات حساب با عنوان «'+document.getElementById("accountTitle"+num).value+'» حذف میشود (مگر آنکه بعد از اعمال تغییرات صفحه ذخیره نشده و صرفاً بسته شود!)، آیا با این حال ادامه می‌دهید؟')){
		return false;
	}
	
	document.getElementById("accountRow"+num).outerHTML="";	   // this deletes the selected row in the table
	
	table=document.getElementById("accountTable");
	var l=(table.rows.length);
	if(l==1){
		document.getElementById("accountDefinitionContainer").innerHTML="";
	}
	if(num==1){
		document.getElementById("bookTitle").focus();
	}else{
		document.getElementById("accountTitle"+(num-1)).focus();
	}
	
	// Now let change the id of all the following rows to the end of table ...
	for(var i=num+1 ; i<=l ; i++){
		document.getElementById("accountRow"+i).setAttribute("id","accountRow"+(i-1));
		document.getElementById("accountTitle"+i).setAttribute("id","accountTitle"+(i-1));
		document.getElementById("startingAmount"+i).setAttribute("id","startingAmount"+(i-1));
		document.getElementById("accountEdit"+i).innerHTML=
			'<table align="center" cellspacing=0 cellpadding=0  style="text-align:center;" border=0>'
				+'<tr>'
					+'<td  rowspan="2"><input type="submit" value="" class="myButton" style="background:url(Main/images/close.png) 20px 20px/20px 20px; border: solid 0px #000000; width:20px; height:20px; margin-bottom:5px;" onclick="delete_accountRow('+(i-1)+')" title="حذف حساب"/></td>'
					+'<td><input type="submit" value="" class="myButton" style="background:url(Main/images/up.png) 0px 10px/10px 10px no-repeat; border: solid 0px #000000; width:10px; height:20px;" onclick="moveUpAccount('+(i-1)+')" title="انتقال به یک ردیف بالاتر"/></td>'
				+'</tr>'
				+'<tr><td><input type="submit" value="" class="myButton" style="background:url(Main/images/down.png) 0px 0px/10px 10px no-repeat; border: solid 0px #000000; width:10px; height:10px;" onclick="moveDownAccount('+(i-1)+')" title="انتقال به یک ردیف پایین‌تر"/></td></tr>'
			+'</table>';
		document.getElementById("accountEdit"+i).setAttribute("id","accountEdit"+(i-1));
	}
}
function moveUpAccount(num){
	if(num>=2){
		var	col1=document.getElementById("accountTitle"+(num-1)).value,
			col2=document.getElementById("startingAmount"+(num-1)).value;
		document.getElementById("accountTitle"+(num-1)).value=document.getElementById("accountTitle"+num).value;
		document.getElementById("startingAmount"+(num-1)).value=document.getElementById("startingAmount"+num).value;
		document.getElementById("accountTitle"+num).value=col1;
		document.getElementById("startingAmount"+num).value=col2;
	}
}
function moveDownAccount(num){
	table=document.getElementById("accountTable");
	var l=table.rows.length;
	if(num<=(l-2)){
		var	col1=document.getElementById("accountTitle"+(num+1)).value,
			col2=document.getElementById("startingAmount"+(num+1)).value;
		document.getElementById("accountTitle"+(num+1)).value=document.getElementById("accountTitle"+num).value;
		document.getElementById("startingAmount"+(num+1)).value=document.getElementById("startingAmount"+num).value;
		document.getElementById("accountTitle"+num).value=col1;
		document.getElementById("startingAmount"+num).value=col2;
	}
}
function saveNewWallet() {
	if(!(document.getElementById("bookTitle").value)){
		alert("لطفاً عنوان پرونده‌ی مالی را وارد نمایید!");
		return false;
	}
	if(document.getElementById("accountTable")==null){
		alert("لطفاً حداقل یک حساب مالی تعریف بفرمایید!");
        return false;
	}
	accounts=[]; startingAmounts=[];
	table=document.getElementById("accountTable");
	var l=table.rows.length;
	for(var i=1 ; i<l ; i++){
		accounts.push(document.getElementById("accountTitle"+i).value);
		var x=document.getElementById("startingAmount"+i).value;
		if(!(Number.isInteger(10*toEn(x)))){	// validate the inputs!
			alert("لطفاً مقادیر موجودی اولیه‌ی حساب‌ها را درست وارد نمایید. مقادیر را به «تومان» وارد کنید و برای «ریال» از یک رقم اعشار استفاده کنید!");
			return false;
		}
		//alert(x);
		startingAmounts.push(x);
	}
	// fill the variable and make a new data in the JSON variables
	classList=[];
	myJSONData = {
		"BookName":document.getElementById("bookTitle").value,
		"Accounts":accounts,				//[],
		"StartingAmounts":startingAmounts,	//[],	may contain numbers both in Fa or En
		"days":[],
		
		"daysInPageNum": 1,					// selectedPageNumShown
		"start2End": 0, 					// StartToEndVar
		"hslider": "calc(46% - 20px)",		// hslider
		"vslider": "calc(80vh - 50px)",		// vslider
		"currentPage": 1					// currentPage
	};
	
	window.location.href='#';						// to colse the popup
	document.getElementById('newBookForm').reset();	//reset the form for later recalling the popup
	document.getElementById("bookName").innerHTML="<span style='color:rgb(238,232,170);'>حساب مالی: </span>"+myJSONData.BookName;
	document.getElementById("classNameDataList").innerHTML="";
	document.getElementById("accountDefinitionContainer").innerHTML="";
	accountLength=accounts.length;
	
	//container.innerHTML="";
	selectedPageNumShown=10;
	fillTheBook();
	selectHowMany();
}




//=================  BUILD A WHOLE NEW PAGE (DAY) INSIDE THE WALLET  ==================//




function addNewDay() {
	if(!myJSONData){
		alert("لطفاً ابتدا یک پرونده‌ی جدید مالی ایجاد نموده و یا یک پرونده‌ی مالی قدیمی را بارگذاری نمایید ...!");
	}else{
		window.location.href='#popupNewDay';
		// to pre-populate the date fields
		document.getElementById("newWeekDAY").value=dayOfWeek[currenDayOfWeek];
		document.getElementById("newDAY").value=toFa(shamsi[2]);
		document.getElementById("newMONTH").value=toFa(shamsi[1]);
		document.getElementById("newYEAR").value=toFa(shamsi[0]);
	
		setTimeout(function(){
			document.getElementById("newDescription").focus();
		}, 500);
	}
}
function addRow_New() {
	//accounts=[], startingAmounts=[]
	var	firstRowAccounts="",
		newRowAccounts="";
	for(var i=0 ; i<accountLength ; i++){
		firstRowAccounts+='<th>'+accounts[i]+'</th>';
	}
	if(document.getElementById("transactionsContainer_New").innerHTML===""){
		document.getElementById("transactionsContainer_New").innerHTML=
			'<table align="center" cellspacing=0 cellpadding=0 id="newTable" style="text-align:center;" border=0>'
				+'<tr style="font-size:80%;">'
					+'<th>موضوع تراکنش</th>'
					+'<th>گروه</th>'
					+firstRowAccounts
				+'</tr>'
			+'</table>';
	}
	table=document.getElementById("newTable");
	var table_len=(table.rows.length);
	for(var i=0 ; i<accountLength ; i++){
		newRowAccounts+='<td><input type="text" id="transactionAccount'+i+'_New'+table_len+'" size=10></td>';
	}
	var row = table.insertRow(table_len).outerHTML=
		'<tr id="row'+table_len+'">'
			+'<td><textarea id="transactionTitle_New'+table_len+'" style="display:inline-block; position:relative; vertical-align:top; width:140px; height:30px; padding:0; line-height:1.1; font-size:80%; overflow:auto; resize:none;" placeholder="موضوع تراکنش"></textarea></td>'
			+'<td><input type="text" list="classNameDataList" autocomplete="off" id="transactionClass_New'+table_len+'" size=8></td>'
			+newRowAccounts
			+'<td  id="edit'+table_len+'" style="vertical-align: middle;">'
				+'<table align="center" cellspacing=0 cellpadding=0  style="text-align:center;" border=0>'
					+'<tr>'
						+'<td  rowspan="2"><input type="submit" value="" class="myButton" style="background:url(Main/images/close.png) 20px 20px/20px 20px; border: solid 0px #000000; width:20px; height:20px; margin-bottom:5px;" onclick="delete_row('+table_len+')" title="حذف تراکنش"/></td>'
						+'<td><input type="submit" value="" class="myButton" style="background:url(Main/images/up.png) 0px 10px/10px 10px no-repeat; border: solid 0px #000000; width:10px; height:20px;" onclick="moveUp('+table_len+')" title="انتقال به یک ردیف بالاتر"/></td>'
					+'</tr>'
					+'<tr><td><input type="submit" value="" class="myButton" style="background:url(Main/images/down.png) 0px 0px/10px 10px no-repeat; border: solid 0px #000000; width:10px; height:10px;" onclick="moveDown('+table_len+')" title="انتقال به یک ردیف پایین‌تر"/></td></tr>'
				+'</table>'
			+'</td>'
		+'</tr>';
		
	setTimeout(function(){
		document.getElementById("transactionTitle_New"+table_len).focus();
	}, 500);
}
function delete_row(num){
	if(!confirm('با ادامه‌ی این کار، اطلاعات تراکنش با عنوان «'+document.getElementById("transactionTitle_New"+num).value+'» حذف میشود (مگر آنکه بعد از اعمال تغییرات صفحه ذخیره نشده و صرفاً بسته شود!)، آیا با این حال ادامه می‌دهید؟')){
		return false;
	}
    
	document.getElementById("row"+num).outerHTML="";		// this deletes the selected row in the table
	
	table=document.getElementById("newTable");
	var l=(table.rows.length);
	if(l==1){
		document.getElementById("transactionsContainer_New").innerHTML="";
	}
	if(num==1){
		document.getElementById("newDescription").focus();
	}else{
		document.getElementById("transactionTitle_New"+(num-1)).focus();
	}
	
	// Now let change the id of all the following rows to the end of table ...
	for(var i=num+1 ; i<=l ; i++){
		document.getElementById("row"+i).setAttribute("id","row"+(i-1));
		document.getElementById("transactionTitle_New"+i).setAttribute("id","transactionTitle_New"+(i-1));
		document.getElementById("transactionClass_New"+i).setAttribute("id","transactionClass_New"+(i-1));
		for(var j=0 ; j<accountLength ; j++){
			document.getElementById("transactionAccount"+j+"_New"+i)
					.setAttribute("id","transactionAccount"+j+"_New"+(i-1));
		}
		document.getElementById("edit"+i).innerHTML=
			'<table align="center" cellspacing=0 cellpadding=0  style="text-align:center;" border=0>'
				+'<tr>'
					+'<td  rowspan="2"><input type="submit" value="" class="myButton" style="background:url(Main/images/close.png) 20px 20px/20px 20px; border: solid 0px #000000; width:20px; height:20px; margin-bottom:5px;" onclick="delete_row('+(i-1)+')" title="حذف تراکنش"/></td>'
					+'<td><input type="submit" value="" class="myButton" style="background:url(Main/images/up.png) 0px 10px/10px 10px no-repeat; border: solid 0px #000000; width:10px; height:20px;" onclick="moveUp('+(i-1)+')" title="انتقال به یک ردیف بالاتر"/></td>'
				+'</tr>'
				+'<tr><td><input type="submit" value="" class="myButton" style="background:url(Main/images/down.png) 0px 0px/10px 10px no-repeat; border: solid 0px #000000; width:10px; height:10px;" onclick="moveDown('+(i-1)+')" title="انتقال به یک ردیف پایین‌تر"/></td></tr>'
			+'</table>';
		document.getElementById("edit"+i).setAttribute("id","edit"+(i-1));
	}
}
function moveUp(num){
	if(num>=2){
		var	col1=document.getElementById("transactionTitle_New"+(num-1)).value,
			col2=document.getElementById("transactionClass_New"+(num-1)).value,
			colAccount=[];
		for(var i=0 ; i<accountLength ; i++){
			colAccount.push(document.getElementById("transactionAccount"+i+"_New"+(num-1)).value);
		}
		document.getElementById("transactionTitle_New"+(num-1)).value=
								document.getElementById("transactionTitle_New"+num).value;
		document.getElementById("transactionClass_New"+(num-1)).value=
								document.getElementById("transactionClass_New"+num).value;
		for(var i=0 ; i<accountLength ; i++){
			document.getElementById("transactionAccount"+i+"_New"+(num-1)).value=
								document.getElementById("transactionAccount"+i+"_New"+num).value;
		}
		document.getElementById("transactionTitle_New"+num).value=col1;
		document.getElementById("transactionClass_New"+num).value=col2;
		for(var i=0 ; i<accountLength ; i++){
			document.getElementById("transactionAccount"+i+"_New"+num).value=colAccount[i];
		}
	}
}
function moveDown(num){
	table=document.getElementById("newTable");
	var l=table.rows.length;
	if(num<=(l-2)){
		var	col1=document.getElementById("transactionTitle_New"+(num+1)).value,
			col2=document.getElementById("transactionClass_New"+(num+1)).value,
			colAccount=[];
		for(var i=0 ; i<accountLength ; i++){
			colAccount.push(document.getElementById("transactionAccount"+i+"_New"+(num+1)).value);
		}
		document.getElementById("transactionTitle_New"+(num+1)).value=
								document.getElementById("transactionTitle_New"+num).value;
		document.getElementById("transactionClass_New"+(num+1)).value=
								document.getElementById("transactionClass_New"+num).value;
		for(var i=0 ; i<accountLength ; i++){
			document.getElementById("transactionAccount"+i+"_New"+(num+1)).value=
								document.getElementById("transactionAccount"+i+"_New"+num).value;
		}
		document.getElementById("transactionTitle_New"+num).value=col1;
		document.getElementById("transactionClass_New"+num).value=col2;
		for(var i=0 ; i<accountLength ; i++){
			document.getElementById("transactionAccount"+i+"_New"+num).value=colAccount[i];
		}
	}
}
function saveNewDay() {
	// fill the variable and make a new data in the JSON variable
	var transactions=[];
	if(document.getElementById("newTable")){
		table=document.getElementById("newTable");
		var l=table.rows.length;
		for(var i=1 ; i<l ; i++){
			var accountsInRow=[];
			for(var j=0 ; j<accountLength ; j++){
				var x=document.getElementById("transactionAccount"+j+"_New"+i).value;
				if(!(Number.isInteger(10*toEn(x)))){	// validate the inputs!
					alert("لطفاً مقادیر تراکنش‌ها را درست وارد نمایید. مقادیر را به «تومان» وارد کنید و برای «ریال» از یک رقم اعشار استفاده کنید!");
					return false;
				}
				accountsInRow.push(x)
			}
			var className = document.getElementById("transactionClass_New"+i).value
			transactions.push(
				{
					"title": document.getElementById("transactionTitle_New"+i).value ,
					"class": className ,
					"expenses":  accountsInRow
				}
			);
			if(classList.indexOf(className)==-1){
				classList.push(className);
			}
		}
	}
	classList.sort(function(a, b){return a.localeCompare(b)});
	document.getElementById("classNameDataList").innerHTML="";
	for(var i=0, l=classList.length; i<l ; i++){
		document.getElementById("classNameDataList").innerHTML+='<option value=\"'+classList[i]+'\">';
	}
	
	var	validatedDay=toEn(document.getElementById("newDAY").value),
		validatedMonth=toEn(document.getElementById("newMONTH").value),
		validatedYEAR=toEn(document.getElementById("newYEAR").value);
	if(Number.isInteger(validatedDay) && validatedDay>=1 && validatedDay<=31
		&& Number.isInteger(validatedMonth) && validatedMonth>=1 && validatedMonth<=12
		&& Number.isInteger(validatedYEAR) && validatedYEAR>=0){
		// for sorting by dates we need to define new variables
		var validatedDayEx = (validatedDay<10) ? "0"+validatedDay : validatedDay;			//e.g. 5 -> 05
		var validatedMonthEx = (validatedMonth<10) ? "0"+validatedMonth : validatedMonth;	//e.g. 5 -> 05
		
		myJSONData.days.push(
			{
				"weekDay": document.getElementById("newWeekDAY").value ,
				"day": validatedDay ,
				"month": validatedMonth ,
				"year": validatedYEAR ,
				"dateForSortAction": Number(validatedYEAR+""+validatedMonthEx+""+validatedDayEx) ,
				"transactions": transactions ,
				"description": document.getElementById("newDescription").value ,
				"endDayLeft": [] ,	// this will be filled after the days are ordered in the fillTheBook() function
				"importance": 0
			}
		);
		
		
		fillTheBook();
		selectHowMany();
		
		
		
		// new day isn't necassarily the last one, so let finally jump to it wherever it is (myJSONData is sorted inside fillTheBook())
		var currentDay;
		for(var day=1, days=myJSONData["days"].length; day<=days; day++) {	//var day in myJSONData["days"]
			if(myJSONData["days"][day-1]["dateForSortAction"] == validatedYEAR+""+validatedMonthEx+""+validatedDayEx){
				currentDay=day;
				break;
			}
		}
		jumpToPageContainingPage(currentDay);
		//document.getElementById("Page"+currentDay).scrollIntoView({behavior: "smooth", block: "center", inline: "nearest"});	// or use inline: "center"
		window.location.href='#Page'+currentDay;	// to colse the popup,   and moves the scrollbar to its right position
		
		
		document.getElementById("transactionsContainer_New").innerHTML="";
		//window.location.href='#';						// to colse the popup
		document.getElementById('formNewPage').reset();	//reset the form for later recalling the popup
	}else{
		alert("لطفاً تاریخ‌ها را درست وارد نمایید. این تاریخ‌ها بعداً در تولید گزارش مورد نیاز هستند.");
	}
}



//=================  EDIT AN ALREADY AVAILABLE DAY IN THE WALLET  ==================//



function editPage(pageNum) {
	pageToBeEdited=pageNum;
	
	//first populate the form with data from the page which is now to be edited
	document.getElementById("PageToEdit").innerHTML=toFa(pageNum);
	
	document.getElementById("editWeekDAY").value=myJSONData["days"][pageNum-1]["weekDay"];
	document.getElementById("editDAY").value=toFa(myJSONData["days"][pageNum-1]["day"]);
	document.getElementById("editMONTH").value=toFa(myJSONData["days"][pageNum-1]["month"]);
	document.getElementById("editYEAR").value=toFa(myJSONData["days"][pageNum-1]["year"]);
	
	document.getElementById("editDescription").value=myJSONData["days"][pageNum-1]["description"];
	
	// next call for the editing form to open
	window.location.href='#popupEditDay';
	
	setTimeout(function(){
		document.getElementById("editDescription").focus();
	}, 500);
	
	
	var l=myJSONData["days"][pageNum-1]["transactions"].length,
		transactionRowsOfTable="",
		firstRowAccounts="";
	//var RowAmounts="";
	for (var i=1 ; i<=l ; i++) {
		//build the already available table of this page with each cell as an "input" tag
		var editRowAccounts="";
		for(var j=0 ; j<accountLength ; j++){
			editRowAccounts+='<td><input type="text" id="transactionAccount'+j+'_Edit'+i+'" size=10></td>';
		}
		transactionRowsOfTable+=
			'<tr id="rowEditTable'+i+'">'
				+'<td><textarea id="transactionTitle_Edit'+i+'" style="display:inline-block; position:relative; vertical-align:top; width:140px; height:30px; padding:0; line-height:1.1; font-size:80%; overflow:auto; resize:none;" placeholder="موضوع تراکنش"></textarea></td>'
				+'<td><input type="text" list="classNameDataList" autocomplete="off" id="transactionClass_Edit'+i+'" size=8></td>'
				+editRowAccounts
				+'<td  id="edit-EditTable'+i+'" style="vertical-align: middle;">'
					+'<table align="center" cellspacing=0 cellpadding=0  style="text-align:center;" border=0>'
						+'<tr>'
							+'<td  rowspan="2"><input type="submit" value="" class="myButton" style="background:url(Main/images/close.png) 20px 20px/20px 20px; border: solid 0px #000000; width:20px; height:20px; margin-bottom:5px;" onclick="delete_rowEditTable('+i+')" title="حذف تراکنش"/></td>'
							+'<td><input type="submit" value="" class="myButton" style="background:url(Main/images/up.png) 0px 10px/10px 10px no-repeat; border: solid 0px #000000; width:10px; height:20px;" onclick="moveUpEditTable('+i+')" title="انتقال به یک ردیف بالاتر"/></td>'
						+'</tr>'
						+'<tr><td><input type="submit" value="" class="myButton" style="background:url(Main/images/down.png) 0px 0px/10px 10px no-repeat; border: solid 0px #000000; width:10px; height:10px;" onclick="moveDownEditTable('+i+')" title="انتقال به یک ردیف پایین‌تر"/></td></tr>'
					+'</table>'
				+'</td>'
			+'</tr>';
	}
	if(myJSONData["days"][pageNum-1]["transactions"][0]){	    // so that there exists at least one transaction, so a table
		for(var i=0 ; i<accountLength ; i++){
			firstRowAccounts+='<th>'+accounts[i]+'</th>';
			//RowAmounts+='<th style="background-color:pink; border:1px solid #555555; border-radius:5px;">'+toFa(myJSONData["days"][pageNum-1]["endDayLeft"][i])+'</th>';
		}
		document.getElementById("transactionsContainer_Edit").innerHTML=
			'<table align="center" cellspacing=0 cellpadding=0 id="editTable" style="text-align:center;" border=0>'
				+'<tr style="font-size:80%;">'
					+'<th>موضوع تراکنش</th>'
					+'<th>گروه</th>'
					+firstRowAccounts
				+'</tr>'
				+transactionRowsOfTable
				//+'<tr style="font-size:80%; color:navy;">'
				//	+'<th colspan="2" style="color:orange; text-shadow:1px 1px black; text-align:left; padding-left:8px;">موجودی:</th>'
				//	+RowAmounts
				//+'</tr>'
			+'</table>';
	}
	for (var i=1 ; i<=l ; i++) {
		//now fill the row of the table ... a new for loop was required for the rows to be settled in the table
		document.getElementById("transactionTitle_Edit"+i).value=
									myJSONData["days"][pageNum-1]["transactions"][i-1]["title"];
		document.getElementById("transactionClass_Edit"+i).value=
									myJSONData["days"][pageNum-1]["transactions"][i-1]["class"];
		for(var j=0 ; j<accountLength ; j++){
			document.getElementById("transactionAccount"+j+"_Edit"+i).value=
									myJSONData["days"][pageNum-1]["transactions"][i-1]["expenses"][j];
		}
	}
}
function addRow_Edit() {
	var	firstRowAccounts="",
		newRowAccounts="";
	for(var i=0 ; i<accountLength ; i++){
		firstRowAccounts+='<th>'+accounts[i]+'</th>';
	}
	if(document.getElementById("transactionsContainer_Edit").innerHTML===""){
		document.getElementById("transactionsContainer_Edit").innerHTML=
			'<table align="center" cellspacing=0 cellpadding=0 id="editTable" style="text-align:center;" border=0>'
				+'<tr style="font-size:80%;">'
					+'<th>موضوع تراکنش</th>'
					+'<th>گروه</th>'
					+firstRowAccounts
				+'</tr>'
			+'</table>';
	}
	table=document.getElementById("editTable");
	var table_len=(table.rows.length);
	for(var i=0 ; i<accountLength ; i++){
		newRowAccounts+='<td><input type="text" id="transactionAccount'+i+'_Edit'+table_len+'" size=10></td>';
	}
	var row = table.insertRow(table_len).outerHTML=
		'<tr id="rowEditTable'+table_len+'">'
			+'<td><textarea id="transactionTitle_Edit'+table_len+'" style="display:inline-block; position:relative; vertical-align:top; width:140px; height:30px; padding:0; line-height:1.1; font-size:80%; overflow:auto; resize:none;" placeholder="موضوع تراکنش"></textarea></td>'
			+'<td><input type="text" list="classNameDataList" autocomplete="off" id="transactionClass_Edit'+table_len+'" size=8></td>'
			+newRowAccounts
			+'<td  id="edit-EditTable'+table_len+'" style="vertical-align: middle;">'
				+'<table align="center" cellspacing=0 cellpadding=0  style="text-align:center;" border=0>'
					+'<tr>'
						+'<td  rowspan="2"><input type="submit" value="" class="myButton" style="background:url(Main/images/close.png) 20px 20px/20px 20px; border: solid 0px #000000; width:20px; height:20px; margin-bottom:5px;" onclick="delete_rowEditTable('+table_len+')" title="حذف تراکنش"/></td>'
						+'<td><input type="submit" value="" class="myButton" style="background:url(Main/images/up.png) 0px 10px/10px 10px no-repeat; border: solid 0px #000000; width:10px; height:20px;" onclick="moveUpEditTable('+table_len+')" title="انتقال به یک ردیف بالاتر"/></td>'
					+'</tr>'
					+'<tr><td><input type="submit" value="" class="myButton" style="background:url(Main/images/down.png) 0px 0px/10px 10px no-repeat; border: solid 0px #000000; width:10px; height:10px;" onclick="moveDownEditTable('+table_len+')" title="انتقال به یک ردیف پایین‌تر"/></td></tr>'
				+'</table>'
			+'</td>'
		+'</tr>';
		
	setTimeout(function(){
		document.getElementById("transactionTitle_Edit"+table_len).focus();
	}, 500);
}
function delete_rowEditTable(num){
	if(!confirm('با ادامه‌ی این کار، اطلاعات تراکنش با عنوان «'+document.getElementById("transactionTitle_Edit"+num).value+'» حذف میشود (مگر آنکه بعد از اعمال تغییرات صفحه ذخیره نشده و صرفاً بسته شود!)، آیا با این حال ادامه می‌دهید؟')){
		return false;
	}
    
	document.getElementById("rowEditTable"+num).outerHTML="";    //this deletes the selected row in the table
	
	table=document.getElementById("editTable");
	var l=(table.rows.length);
	if(l==1){
		document.getElementById("transactionsContainer_Edit").innerHTML="";
	}
	if(num==1){
		document.getElementById("editDescription").focus();
	}else{
		document.getElementById("transactionTitle_Edit"+(num-1)).focus();
	}
	
	// Now let change the id of all the following rows to the end of table ...
	for(var i=num+1 ; i<=l ; i++){
		document.getElementById("rowEditTable"+i).setAttribute("id","rowEditTable"+(i-1));
		document.getElementById("transactionTitle_Edit"+i).setAttribute("id","transactionTitle_Edit"+(i-1));
		document.getElementById("transactionClass_Edit"+i).setAttribute("id","transactionClass_Edit"+(i-1));
		for(var j=0 ; j<accountLength ; j++){
			document.getElementById("transactionAccount"+j+"_Edit"+i)
					.setAttribute("id","transactionAccount"+j+"_Edit"+(i-1));
		}
		document.getElementById("edit-EditTable"+i).innerHTML=
			'<table align="center" cellspacing=0 cellpadding=0  style="text-align:center;" border=0>'
				+'<tr>'
					+'<td  rowspan="2"><input type="submit" value="" class="myButton" style="background:url(Main/images/close.png) 20px 20px/20px 20px; border: solid 0px #000000; width:20px; height:20px; margin-bottom:5px;" onclick="delete_rowEditTable('+(i-1)+')" title="حذف تراکنش"/></td>'
					+'<td><input type="submit" value="" class="myButton" style="background:url(Main/images/up.png) 0px 10px/10px 10px no-repeat; border: solid 0px #000000; width:10px; height:20px;" onclick="moveUpEditTable('+(i-1)+')" title="انتقال به یک ردیف بالاتر"/></td>'
				+'</tr>'
				+'<tr><td><input type="submit" value="" class="myButton" style="background:url(Main/images/down.png) 0px 0px/10px 10px no-repeat; border: solid 0px #000000; width:10px; height:10px;" onclick="moveDownEditTable('+(i-1)+')" title="انتقال به یک ردیف پایین‌تر"/></td></tr>'
			+'</table>';
		document.getElementById("edit-EditTable"+i).setAttribute("id","edit-EditTable"+(i-1));
	}
}
function moveUpEditTable(num){
	if(num>=2){
		var	col1=document.getElementById("transactionTitle_Edit"+(num-1)).value,
			col2=document.getElementById("transactionClass_Edit"+(num-1)).value,
			colAccount=[];
		for(var i=0 ; i<accountLength ; i++){
			colAccount.push(document.getElementById("transactionAccount"+i+"_Edit"+(num-1)).value);
		}	document.getElementById("transactionTitle_Edit"+(num-1)).value=document.getElementById("transactionTitle_Edit"+num).value;
		document.getElementById("transactionClass_Edit"+(num-1)).value=document.getElementById("transactionClass_Edit"+num).value;
		for(var i=0 ; i<accountLength ; i++){
			document.getElementById("transactionAccount"+i+"_Edit"+(num-1)).value=
								document.getElementById("transactionAccount"+i+"_Edit"+num).value;
		}
		document.getElementById("transactionTitle_Edit"+num).value=col1;
		document.getElementById("transactionClass_Edit"+num).value=col2;
		for(var i=0 ; i<accountLength ; i++){
			document.getElementById("transactionAccount"+i+"_Edit"+num).value=colAccount[i];
		}
	}
}
function moveDownEditTable(num){
	table=document.getElementById("editTable");
	var l=table.rows.length;
	if(num<=(l-2)){
		var	col1=document.getElementById("transactionTitle_Edit"+(num+1)).value,
			col2=document.getElementById("transactionClass_Edit"+(num+1)).value,
			colAccount=[];
		for(var i=0 ; i<accountLength ; i++){
			colAccount.push(document.getElementById("transactionAccount"+i+"_Edit"+(num+1)).value);
		}
		document.getElementById("transactionTitle_Edit"+(num+1)).value=document.getElementById("transactionTitle_Edit"+num).value;
		document.getElementById("transactionClass_Edit"+(num+1)).value=document.getElementById("transactionClass_Edit"+num).value;
		for(var i=0 ; i<accountLength ; i++){
			document.getElementById("transactionAccount"+i+"_Edit"+(num+1)).value=
								document.getElementById("transactionAccount"+i+"_Edit"+num).value;
		}
		document.getElementById("transactionTitle_Edit"+num).value=col1;
		document.getElementById("transactionClass_Edit"+num).value=col2;
		for(var i=0 ; i<accountLength ; i++){
			document.getElementById("transactionAccount"+i+"_Edit"+num).value=colAccount[i];
		}
	}
}
function saveEditedPage() {
	// fill the variable and make a new data in the JSON variable
	var transactions=[];
	if(document.getElementById("editTable")){
		table=document.getElementById("editTable");
		var l=table.rows.length;
		for(var i=1 ; i<l ; i++){
			var accountsInRow=[];
			for(var j=0 ; j<accountLength ; j++){
				var x=document.getElementById("transactionAccount"+j+"_Edit"+i).value;
				if(!(Number.isInteger(10*toEn(x)))){	// validate the inputs!
					alert("لطفاً مقادیر تراکنش‌ها را درست وارد نمایید. مقادیر را به «تومان» وارد کنید و برای «ریال» از یک رقم اعشار استفاده کنید!");
					return false;
				}
				accountsInRow.push(x)
			}
			transactions.push(
				{
					"title": document.getElementById("transactionTitle_Edit"+i).value ,
					"class": document.getElementById("transactionClass_Edit"+i).value ,
					"expenses":  accountsInRow
				}
			);
		}
	}
	var	validatedDay=toEn(document.getElementById("editDAY").value),
		validatedMonth=toEn(document.getElementById("editMONTH").value),
		validatedYEAR=toEn(document.getElementById("editYEAR").value);
	if(Number.isInteger(validatedDay) && validatedDay>=1 && validatedDay<=31
		&& Number.isInteger(validatedMonth) && validatedMonth>=1 && validatedMonth<=12
		&& Number.isInteger(validatedYEAR) && validatedYEAR>=0){
		// for sorting by dates we need to define new variables
		var validatedDayEx = (validatedDay<10) ? "0"+validatedDay : validatedDay;			//e.g. 5 -> 05
		var validatedMonthEx = (validatedMonth<10) ? "0"+validatedMonth : validatedMonth;	//e.g. 5 -> 05
		
		var imp=myJSONData["days"][pageToBeEdited-1]["importance"];
		
		myJSONData.days.splice((pageToBeEdited-1), 1,	// deletes the original one and insert the edited one at the same place in the array
			{
				"weekDay": document.getElementById("editWeekDAY").value ,
				"day": validatedDay ,
				"month": validatedMonth ,
				"year": validatedYEAR ,
				"dateForSortAction": Number(validatedYEAR+""+validatedMonthEx+""+validatedDayEx) ,
				"transactions": transactions ,
				"description": document.getElementById("editDescription").value ,
				"endDayLeft": [] ,	// this will be filled after the days are ordered in the fillTheBook() function
				"importance": imp
			}
		);
		
		
		
		// re-list the transactions' classNames
		classList=[];
		for (var day=0, days=myJSONData["days"].length; day<days; day++) {	//var day in myJSONData["days"]
			for (var transaction in myJSONData["days"][day]["transactions"]) {
				var className=myJSONData["days"][day]["transactions"][transaction]["class"];
				if(classList.indexOf(className)==-1){classList.push(className);}
			}
		}
		classList.sort(function(a, b){return a.localeCompare(b)});
		document.getElementById("classNameDataList").innerHTML="";
		for(var i=0, l=classList.length; i<l ; i++){
			document.getElementById("classNameDataList").innerHTML+='<option value=\"'+classList[i]+'\">';
		}
		
		
		fillTheBook();
		selectHowMany();
		jumpToPageContainingPage(pageToBeEdited);
		
		
		//reset the form for later recalling the popup
		document.getElementById('formEditedPage').reset();
		document.getElementById("transactionsContainer_Edit").innerHTML="";
		window.location.href='#';	// to colse the popup
	}else{
		alert("لطفاً تاریخ‌ها را درست وارد نمایید. این تاریخ‌ها بعداً در تولید گزارش مورد نیاز هستند.");
	}
}



//=================  DELETE AN ALREADY AVAILABLE DAY IN THE WALLET  ==================//



function deletePage(pageNum){
	if(!confirm('با ادامه‌ی این کار، اطلاعات وارد شده برای برگه‌ی '+toFa(pageNum)+' (روز '+toFa(myJSONData.days[pageNum-1]["weekDay"])+'، '+toFa(myJSONData.days[pageNum-1]["year"])+'/'+toFa(myJSONData.days[pageNum-1]["month"])+'/'+toFa(myJSONData.days[pageNum-1]["day"])+') حذف میشود، آیا با این حال ادامه می‌دهید؟')){
		return false;
	}
	
	var pagesCitingThisPage=[];
	for (var day=1, days=myJSONData["days"].length; day<=days; day++) {			//var day in myJSONData["days"]
		if(document.getElementById("Page"+day).innerHTML.indexOf( "jumpToPageContainingPage("+pageNum+")" )!=-1 && day!=pageNum){
			pagesCitingThisPage.push(day);
		}
	}
	if(pagesCitingThisPage.length==0){
		if(!confirm('اگرچه از برگه‌ی دیگری به این برگه ارجاعی داده نشده است، اما آیا همچنان به حذف این برگه اطمینان دارید؟')){
			return false;
		}
	}else if(pagesCitingThisPage.length==1){
		if(!confirm('توجه: از برگه‌ی «'+toFa(pagesCitingThisPage[0])+'» به این برگه ارجاع داده شده است، آیا همچنان به حذف این برگه اطمینان دارید؟')){
			return false;
		}
	}else{
		if(!confirm('توجه: از برگه‌های «'+toFa(pagesCitingThisPage.join("، "))+'» به این برگه ارجاع داده شده است، آیا همچنان به حذف این برگه اطمینان دارید؟')){
			return false;
		}
	}
	
	
	myJSONData.days.splice((pageNum-1), 1);	// deletes the page from the array
	// re-list the transactions' classNames
	classList=[];
	for (var day=0, days=myJSONData["days"].length; day<days; day++) {	//var day in myJSONData["days"]
		for (var transaction in myJSONData["days"][day]["transactions"]) {
			var className=myJSONData["days"][day]["transactions"][transaction]["class"];
			if(classList.indexOf(className)==-1){classList.push(className);}
		}
	}
	classList.sort(function(a, b){return a.localeCompare(b)});
	document.getElementById("classNameDataList").innerHTML="";
	for(var i=0, l=classList.length; i<l ; i++){
		document.getElementById("classNameDataList").innerHTML+='<option value=\"'+classList[i]+'\">';
	}
	
	
	fillTheBook();
	selectHowMany();
}



//=================  FILL THE WEBPAGE WITH THE DATA ALREADY AQUIRED  ==================//




function changeDirection(){
	myJSONData.start2End = StartToEndVar = (StartToEndVar)? 0 : 1;
	saveToCache();
	
	// to reverse the order of pages in 'container', whatsoever it was previously ...
	// obtained from http://jsfiddle.net/t6q44/5/ (https://stackoverflow.com/a/16919947)
	var parent=document.getElementsByClassName('container')[0],		// strange! using « getElementById("container") » doesn't work here
		divs=parent.children;
	for(var i=divs.length-1; i--; ) {
		parent.appendChild(divs[i]);
	}
	
	selectHowMany();
}

function fillTheBook() {
	var containerContent="";
	
	if(myJSONData != undefined){
		myJSONData["days"].sort(function(a, b){return a.dateForSortAction - b.dateForSortAction});
	}else{
		return false;
	}
	saveToCache();	// as every change in "myJSONData" will be followed by "fillTheBook()", this is suitable to be placed at here, to always save the latest version of "myJSONData" in the browser's cache!
	
	
	var accountsDayStart=[], accountsDayEnd=[];
	for(var i=0 ; i<accountLength ; i++){
		accountsDayEnd.push(toEn(myJSONData["StartingAmounts"][i]));
	}
	
	
	var nestedListLevel=0;
	for(var day=1, days=myJSONData["days"].length; day<=days; day++) {			//var day in myJSONData["days"]
		var date=myJSONData["days"][day-1]["weekDay"]
				+" "+toFa(myJSONData["days"][day-1]["year"]
				+"/"+myJSONData["days"][day-1]["month"]
				+"/"+myJSONData["days"][day-1]["day"]),
			description=myJSONData["days"][day-1]["description"],
			table="",
			transactionRowsOfTable="",
			importantClass=(myJSONData["days"][day-1]["importance"])? ' important' : '';
		
		
		
		description=(description!="")?
			
			description	.replace(/(\×\×)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<strong>$2</strong>")
						.replace(/(\×)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<em>$2</em>")
						.replace(/(\/ـ\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<u>$2</u>")
						.replace(/(\/-\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<s>$2</s>")
						
						.replace(/(\/ق\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:rgb(220,20,60)'>$2</span>")
						.replace(/(\/آ\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:rgb(0,0,139)'>$2</span>")
						.replace(/(\/س\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:darkgreen'>$2</span>")
						.replace(/(\/زرد\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='background-color:yellow'>$2</span>")
						
						//for capturing links ...	   //use as   /لینک{متن}{http://www.address.com}[عنوان]
						.replace(/(?:\/لینک)(?:\{[ \t]*([^\}]*)[ \t]*\})[ \t]*(?:\{[ \t]*([^\}]*)[ \t]*\})[ \t]*(?:\[([^\]]*)\])?/g,"<a href='$2' title='$3'>$1</a> ")
						// to generate "لنگرگاه" everywhere the user will refer to later ... 	//use as   /لنگرگاه{key}
						.replace(/(?:\/لنگرگاه)(?:\{[ \t]*(.*?)[ \t]*\})/g, "<span id='anchorOnPage"+day+"_$1'></span>")
						// to define lists		// In this program, putting a dot before + or + does nothing and is ignored!
						.replace(/^[ \t]*(\+|\*)[ \t]*(.+)/gm, function(x,y2,y3){
							var i=1;	if(i > nestedListLevel){nestedListLevel=i;}
							y3=(y2=="+")? "<ol><li>"+y3+"</li></ol>" : "<ul><li>"+y3+"</li></ul>";
							var temp=1, yt=y3, ytt="";
							while(temp){
								ytt=yt	.replace(/\<li\>(?:\+)[ \t]*(.+)\<\/li\>/, "<ol><li>$1</li></ol>")
										.replace(/\<li\>(?:\*)[ \t]*(.+)\<\/li\>/, "<ul><li>$1</li></ul>");
								if(ytt==yt){
									temp=0;		// so the loop is terminated
									i--;
									
									// to let change the bullet fot this item and its following of the same level
									ytt=ytt.replace(/(?:\<ul\>\<li\>)(?:\[(.*)\])?/, function(x,y){
										return (y!=undefined)? "<ul style='list-style:\" "+y+" \" outside;'><li>" : "<ul><li>";
									});
								}
								yt=ytt;
								i++; if(i > nestedListLevel){nestedListLevel=i;}
							}
							return yt;
						})
						
						
						.replace(/(?:\()[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*(?:\))/g,"(<span style='color:grey'>$1</span>)")
						.replace(/\n/g,"<br>")
						.replace(/(\<\/[ou]l\>)\<br\>/g,"$1")
			
			: " -";
		
		
		
		var i=accountsDayEnd.length;    while(i--) accountsDayStart[i]=accountsDayEnd[i];    // copies the array
		
		for (var transaction in myJSONData["days"][day-1]["transactions"]) {
			var accountRow="";
			for(var i=0 ; i<accountLength ; i++){
				//calculation
				accountsDayEnd[i]+=toEn(myJSONData["days"][day-1]["transactions"][transaction]["expenses"][i]);
				//multiply and divide by 10 to avoid round-off errors in JS (amounts in Tomans instead of Rials)
				accountsDayEnd[i]=Math.round( accountsDayEnd[i] * 10 ) / 10;
				
				//demonstration
				accountRow+=
					'<td>'+numberWithSeparators(myJSONData["days"][day-1]["transactions"][transaction]["expenses"][i])+'</td>';
			}
			transactionRowsOfTable+=
				'<tr>'
					+'<td style="font-size:80%;">'+toFa(Number(transaction)+1)+'</td><td style="text-align:right; font-size:85%;">'+myJSONData["days"][day-1]["transactions"][transaction]["title"]+'</td><td  class="rotateHeader">'+myJSONData["days"][day-1]["transactions"][transaction]["class"]+'</td>'+accountRow
				+'</tr>';
		}
		
		//now the coputations for the present date is complete
		myJSONData["days"][day-1]["endDayLeft"]=[];
		for(var i=0 ; i<accountLength ; i++){
			myJSONData["days"][day-1]["endDayLeft"].push(accountsDayEnd[i]);
		}
		
		// now let feed the available data to a table, if its required for this date to have any table
		if(myJSONData["days"][day-1]["transactions"][0]){ //so that there exists at least one transaction, so needs a table
			var firstRowAccounts="",
				rowAccountsDayStart="",
				rowAccountsDayEnd="";
			for(var i=0 ; i<accountLength ; i++){
				firstRowAccounts+='<th>'+accounts[i]+'</th>';
				rowAccountsDayStart+='<td>'+numberWithSeparators(accountsDayStart[i])+'</td>';
				rowAccountsDayEnd+='<td>'+numberWithSeparators(accountsDayEnd[i])+'</td>';
			}
			
			table=
				'<table class="transactionsDisplay" style="margin-top:5px;">'
					+'<tr style="font-size:80%;">'
						+'<th class="rotateHeaderVertical" style=" width:10px;"><div>ردیف</div></th><th>عنوان تراکنش</th><th class="rotateHeader">گروه</th>'+firstRowAccounts
					+'</tr>'
					+'<tr style="font-size:80%;">'
						+'<td colspan="3"  style="text-align:left; padding-left:10px; font-weight:bold;">موجودی</td>'+rowAccountsDayStart
					+'</tr>'
					+transactionRowsOfTable
					+'<tr style="font-size:80%;">'
						+'<td colspan="3"  style="text-align:left; padding-left:10px; font-weight:bold;">موجودی</td>'+rowAccountsDayEnd
					+'</tr>'
				+'</table>';
		}
		
		
		
		containerContent+=
			'<div class="newpage'+importantClass+'" id="Page'+day+'" style="width:'+hslider+'; height:'+vslider+'">'
				+'<div class="pageHeader">'
					+'<div style="float:right;">برگه‌ی '+toFa(day)+'</div>'
					+'<div>تاریخ: <span style="color:crimson; font-weight:bold;">'+date+'</span></div>'
					+'<span onclick="deletePage('+day+');" class="myButton" title="حذف" style="line-height:25px; font-size:25px; color:Crimson; cursor:pointer; margin:2px 3px 1px 2px; float:left;">⊠</span>'
					+'<span onclick="editPage('+day+');" class="myButton" title="ویرایش"style="line-height:25px; font-size:25px; color:rgb(100,150,50); cursor:pointer; margin:4px 0 1px 2px; float:left;">✎</span>'
					+'<span onclick="'
								+'var el=document.getElementById(\'Page'+day+'\'); '
								+'if(el.classList.contains(\'important\')){'
									+'el.classList.remove(\'important\');'
									+'myJSONData[\'days\']['+(day-1)+'][\'importance\']=0;'
								+'}else{'
									+'el.classList.add(\'important\');'
									+'myJSONData[\'days\']['+(day-1)+'][\'importance\']=1;'
								+'}'
								+'saveToCache();'
							+'" class="myButton" title="تعیین برگه به عنوان مهم/معمولی" style="line-height:25px; font-size:18px; text-shadow:0.5px 0.5px 0px black; cursor:pointer; margin:1px 0 1px 4px; float:left;">🚩</span>'
				+'</div>'
				+table
				+'<div style="text-align:justify; margin-top:5px;"><span style="font-weight:bold;">توضیحات: </span>'+description+'</div>'
			+'</div>';
		
	}
	container.innerHTML=containerContent;
	
	
	// to refer to the generated "لنگرگاه" ...	//use as   /لنگر{کلید: key}{متن لینک}
	container.innerHTML=container.innerHTML
						.replace(/(?:\/لنگر)(?:\{[ \t]*(.*?)[ \t]*\})(?:\{[ \t]*(.*?)[ \t]*\})/g,  function(x,y1,y2){
							if(container.contains(document.querySelector('[id^="anchor"][id$="_'+y2+'"]'))){
								var id = document.querySelector('[id^="anchor"][id$="_'+y2+'"]').id;
								var targetDay=id.replace(/anchorOnPage(\d*)\_.*/,"$1");
								return "<a href='#"+id+"' onclick='jumpToPageContainingPage("+targetDay+");'>"+y1+"</a>"
					+" از برگه‌ی "
									+toFa(targetDay);
							}else{
								return	"<a href='#' onclick='alert(\"لنگرگاه این لنگر تعریف نشده است!\");'>"+y1+"</a>";
							}
						});
	// to take care of lists and nested lists
	while(nestedListLevel){
		container.innerHTML=container.innerHTML
						.replace(/\<\/ol\>(?:\<br\>)?\<ol\>/g,"")
						.replace(/\<\/ul\>(?:\<br\>)?\<ul\>/g,"")
						.replace(/\<\/li\>\<ol\>/g,"\<ol\>")
						.replace(/\<\/li\>\<ul\>/g,"\<ul\>");
		nestedListLevel--;
	}
	
	
	// to properly set the order of pages from start to end or the reverse ...
	// obtained from http://jsfiddle.net/t6q44/5/ (https://stackoverflow.com/a/16919947)
	var parent=document.getElementsByClassName('container')[0],		// strange! using « getElementById("container") » doesn't work here
		divs=parent.children;
	if(StartToEndVar==0 && divs.length>0){	//to display the pages in reverse order, the last page at top-right of the webpage
		for(var i=divs.length-1; i--; ) {
	   		parent.appendChild(divs[i]);
		}
	}
}

function jumpToPageContainingPage(x){
	// 1 <= x <= myJSONData["days"].length;
	if(StartToEndVar==0){	//pages are displayed in reverse order
		myJSONData.currentPage = currentPage = Math.ceil((myJSONData["days"].length - x + 1) / selectedPageNumShown);
	}else{
		myJSONData.currentPage = currentPage = Math.ceil(x / selectedPageNumShown);
	}
	saveToCache();
	
	document.getElementById('goToPage').value=toFa(currentPage)+'\/'+toFa(totalPageNumber);
	
	changePage();
}




//======  CHANGE THE SIZE OF THE PAGES SHOWN ON THE WEBPAGE, EACH BELONGING TO A DAY  =======



document.getElementById("hSizeSlider").oninput = function() {
	for(var i=1, l=days=myJSONData["days"].length; i<=l ; i++){
		hslider='calc('+ Number(this.value) +'% - 20px)';
		document.getElementById("Page"+i).style.width = myJSONData.hslider = hslider;
		saveToCache();
	}
}
document.getElementById("vSizeSlider").oninput = function() {
	for(var i=1, l=days=myJSONData["days"].length; i<=l ; i++){
		vslider='calc('+ Number(this.value) +'vh - 50px)';
		document.getElementById("Page"+i).style.height = myJSONData.vslider = vslider;
		saveToCache();
	}
}




//====================  OPEN A NEW FILE  =====================



var openFile=document.getElementById("Openfile");

function openFunction(){
	if(myJSONData){
		if(!confirm('با باز کردن فایل جدید ورودی‌های ذخیره‌نشده‌ی فعلی از دست می‌روند، آیا ادامه می‌دهید؟')){
			return false;
		}
	}
	openFile.click();	// this opens the file browser dialog for selecting a file to open
	return;
};

openFile.addEventListener('change', function() {
	var fileToLoad=openFile.files[0];			// the selected file itself as an object?
	var fileToLoadAddress=openFile.value;		// the relative or absolute address of the selected file
	
	document.getElementById("bookName").innerHTML="<span style='color:rgb(238,232,170);'>فایل: </span>"+fileToLoadAddress.split('\\').pop()  .replace(/(.txt)/,"").replace(/\./g,":");	// this writes the name of the file opened in the header at the top
	//.replace(/(?:^|[^\d۰-۹])(([01۰۱]?[\d۰-۹])|([2۲][0-3۰-۳])|(24|۲۴)).([0-5۰-۵]?[\d۰-۹])(?:$|[^\d۰-۹])/g,"$1:$5");	// to match time
	
	if(fileToLoad){
		var reader=new FileReader();
		reader.readAsText(fileToLoad, "UTF-8");
		reader.onload=function(event){
			myJSONData = JSON.parse(event.target.result);
			
			// for backward compatibility (files produced by previous versions didn't have endDayLeft entrance for days)
			for(var day in myJSONData["days"]){
				if(!myJSONData["days"][day]["endDayLeft"]){
					myJSONData["days"][day]["endDayLeft"]=[];
				}
			}
		
			// re-populate the global variables required all over the program
			accountLength=myJSONData.Accounts.length;	accounts=[];	startingAmounts=[];
			for(var i=0; i<accountLength; i++){
				accounts.push(myJSONData.Accounts[i]);
				startingAmounts.push(myJSONData.StartingAmounts[i]);
			}
			
			
			// list the transactions' classNames
			classList=[];
			for (var day=0, days=myJSONData["days"].length; day<days; day++) {	//var day in myJSONData["days"]
				for (var transaction in myJSONData["days"][day]["transactions"]) {
					var className=myJSONData["days"][day]["transactions"][transaction]["class"];
					if(classList.indexOf(className)==-1){classList.push(className);}
				}
			}
			classList.sort(function(a, b){return a.localeCompare(b)});
            document.getElementById("classNameDataList").innerHTML="";
			for(var i=0, l=classList.length; i<l ; i++){
				document.getElementById("classNameDataList").innerHTML+='<option value=\"'+classList[i]+'\">';
			}
			
			
			selectedPageNumShown = myJSONData.daysInPageNum;
			StartToEndVar = myJSONData.start2End;
			hslider = myJSONData.hslider;
			vslider = myJSONData.vslider;
			currentPage = myJSONData.currentPage;
		
			document.getElementById("hSizeSlider").value = hslider.replace(/[^\d]*(\d+)\%.*/,"$1");
			document.getElementById("vSizeSlider").value = vslider.replace(/[^\d]*(\d+)vh.*/,"$1");
			
			fillTheBook();
			selectHowMany();
		}
		reader.onerror=function(event){
			document.getElementById("container").innerHTML="بارگذاری فایل انتخاب شده ناموفق بود!";
		}
	}
});



// -----------------------------------------------------------------------------
// Drag&Drop text file to open the file's content there
// got the inspiration from "http://devjs.eu/en/drag-multiple-text-files-to-your-web-application-with-html5-and-javascript/"


document.getElementById("container").addEventListener('dragover', dragOver);
document.getElementById("container").addEventListener('dragend', dragEnd);
document.getElementById("container").addEventListener('drop', readText, false);

function dragOver(e){
	e.stopPropagation(); // for some browsers stop redirecting
	e.preventDefault();
	//e.dataTransfer.effectAllowed = "move";		// when the curser changed, the file can be dropped!
	return false;
}
function dragEnd(e){
	e.stopPropagation(); // for some browsers stop redirecting
	e.preventDefault();
	return false;
}
function readText(e){
	e.stopPropagation(); // for some browsers stop redirecting
	e.preventDefault();
	
	var fileData, reader, file=e.dataTransfer.files[0];
	if (!file) {return false;}
	
	if(myJSONData){
		if(!confirm('با باز کردن فایل جدید ورودی‌های ذخیره‌نشده‌ی فعلی از دست می‌روند، آیا ادامه می‌دهید؟')){
			return false;
		}
	}
    
    //to read the content of the file
    reader=new FileReader();
	reader.readAsText(file, "UTF-8");
	reader.onload=function(event){
		myJSONData = JSON.parse(event.target.result);
		
		// for backward compatibility (files produced by previous versions didn't have endDayLeft entrance for days)
		for(var day in myJSONData["days"]){
			if(!myJSONData["days"][day]["endDayLeft"]){
				myJSONData["days"][day]["endDayLeft"]=[];
			}
		}
		
		// re-populate the global variables required all over the program
		accountLength=myJSONData.Accounts.length;	accounts=[];	startingAmounts=[];
		for(var i=0; i<accountLength; i++){
			accounts.push(myJSONData.Accounts[i]);
			startingAmounts.push(myJSONData.StartingAmounts[i]);
		}
		
		
		// list the transactions' classNames
		classList=[];
		for (var day=0, days=myJSONData["days"].length; day<days; day++) {	//var day in myJSONData["days"]
			for (var transaction in myJSONData["days"][day]["transactions"]) {
				var className=myJSONData["days"][day]["transactions"][transaction]["class"];
				if(classList.indexOf(className)==-1){classList.push(className);}
			}
		}
		classList.sort(function(a, b){return a.localeCompare(b)});
		document.getElementById("classNameDataList").innerHTML="";
		for(var i=0, l=classList.length; i<l ; i++){
			document.getElementById("classNameDataList").innerHTML+='<option value=\"'+classList[i]+'\">';
		}
		
		
		
		selectedPageNumShown = myJSONData.daysInPageNum;
		StartToEndVar = myJSONData.start2End;
		hslider = myJSONData.hslider;
		vslider = myJSONData.vslider;
		currentPage = myJSONData.currentPage;
		
		document.getElementById("hSizeSlider").value = hslider.replace(/[^\d]*(\d+)\%.*/,"$1");
		document.getElementById("vSizeSlider").value = vslider.replace(/[^\d]*(\d+)vh.*/,"$1");
		
		fillTheBook();
		selectHowMany();
	}
	reader.onerror=function(event){
		document.getElementById("container").innerHTML="بارگذاری فایل انتخاب شده ناموفق بود!";
	}
	
	
	document.getElementById("bookName").innerHTML="<span style='color:rgb(238,232,170);'>فایل: </span>"+file.name.split('\\').pop()  .replace(/(.txt)/,"").replace(/\./g,":");	// this writes the name of the file opened in the header at the top
	//.replace(/(?:^|[^\d۰-۹])(([01۰۱]?[\d۰-۹])|([2۲][0-3۰-۳])|(24|۲۴)).([0-5۰-۵]?[\d۰-۹])(?:$|[^\d۰-۹])/g,"$1:$5");	// to match time
}




//====================  SAVE TO A FILE (PERMANENT BACKUP)  =====================




function saveData(){
	if(myJSONData){
		persianDateTime();
		var title=myJSONData["BookName"],
			today=toFa(shortDate).replace(/\:/g,".");
	
		title=title.length>30	?	title.substring(0,30)+" ..."	:	title;
		
		// ------- if using  download.js
		download(  JSON.stringify(myJSONData)	,	title+" ("+today+").txt"	,	"text/html");
		
	}else{
		alert("هنوز داده‌ای وارد نشده که ذخیره شود!");
	}
};



//=============  USE localStorage OF HTML5 TO AUTOMATE SAVING OF DATA IN CACHE ==============//



function saveToCache(){
	window.localStorage["savedInCahe"] = JSON.stringify(myJSONData);	// stores the data to the browser's cache
	
	document.getElementById('save-log').style.display = 'inline-block';
	setTimeout(function() {
		document.getElementById('save-log').style.display = 'none';	// the save-log will last for 1 second (1000 ms) before it will become display-none ...
	}, 1000);
}



//===============  TO PRODUCE AND SHOW A REPORT OF THE TRANSACTIONS  ================//



var report=0;		// assign the value at the start of the program
function showReport(){
	// to check weather report is not being shown
	if(report==0){
		//show report in tables & charts
		if(myJSONData && myJSONData["days"].length!=0){
			var check=0;
			for(var day in myJSONData["days"]){
				if(myJSONData["days"][day]["transactions"].length!=0){	//checks for at least one transaction to exist
					document.getElementById('reportShowHide').title = 'مخفی کردن گزارش مالی';
					document.getElementById('container').style.display = 'none';
					document.getElementById('addButtonContainer').style.display = 'none';
					document.getElementById('report').style.display = 'inherit';
					
					generateReport(0,myJSONData.days.length-1);
					report=1;
					check=1;
					break; 	// don't continue the loop, at least 1 transaction exists, so go ahead to report!
				}
			}
			if(check==0){alert("داده‌ای برای رسم نمودار و ارائه‌ی گزارش وجود ندارد");}
		}else{
			alert("داده‌ای برای رسم نمودار و ارائه‌ی گزارش وجود ندارد");
		}
	}else{
		//show the book of transactions
		document.getElementById('reportShowHide').title = 'نمایش گزارش مالی';
		document.getElementById('report').style.display = 'none';
		document.getElementById('container').style.display = 'initial';
		document.getElementById('addButtonContainer').style.display = 'initial';
		report=0;
	}
}
function generateReport(s,e){
	var color=[
		// colors from  https://htmlcolorcodes.com/color-chart/
		'#3f51b5','#880e4f','#fdd835',
		// color palettes from  http://colrd.com
		'rgb(221,57,72)','rgb(226,106,58)','rgb(220,143,54)','rgb(231,170,58)','rgb(68,160,96)',
		'rgb(67,140,141)','rgb(47,101,125)','rgb(52,58,110)','rgb(96,50,127)',
		'#198100','#4dc32c','#bef43d','#387e73','#33c199','#87ff9d','#2469ba','#75cffa',
		'#bd5dfd','#891bb0','#f16391','#feadc0','#c6281c','#f95a00','#ff9e32','#ffe07a',
		
		// with help from http://phrogz.net/css/distinct-colors.html, added 4 colors at the beginning
		//'#e6194b', '#3cb44b', '#ffe119', '#4363d8', '#ff0000', '#ffcc00', '#66ff00', '#00ff99', '#0099ff', '#6600ff', '#ff00cc', '#ff3300', '#ffff00', '#33ff00', '#00ffcc', '#0066ff', '#9900ff', '#ff0099', '#ff6600', '#ccff00', '#00ff33', '#00ffff', '#0033ff', '#cc00ff', '#ff0066', '#ff9900', '#99ff00', '#00ff66', '#00ccff', '#0000ff', '#ff00ff', '#ff0033'
		'#e6194b', '#3cb44b', '#ffe119', '#4363d8', '#ff0000', '#ffff00', '#00ff40', '#00bfff', '#8000ff', '#ff0080', '#ff4000', '#bfff00', '#00ff80', '#007fff', '#bf00ff', '#ff0040', '#ff8000', '#7fff00', '#00ffbf', '#0040ff', '#ff00ff', '#ffbf00', '#40ff00', '#00ffff', '#0000ff', '#ff00bf'
	];
	
	
	if(s>e){var temp=s; s=e; e=temp;}	// to ensure s<=e
	
	inputReport(s,e); 					// to assign values to the dateSelectionForm at right-bottom of the page
	
	var dataLine={"labels":[], "accounts":[]},		//labels are days, or months	//each accounts[i] is itself an array
		classesByDay=[],							//in form of [{"name":XXX, "labels":[], "values":[]} , ...]
		classesByMonth={"labels":[], "datasets":[]},//in form of {"labels":[], "datasets":[{"name":XXX,  "values":[]} , ...]}
		classesTotal=[];							//in form of  [{"name":XXX,  "value":YYY} , ...]
	
	
	
	// first populate the array "dataLine"
	var accountsWholeStart=[], accountsTotalExpenses=[], accountsTotalIncomes=[], 
		firstRowAccounts="", rowAccountsDayStart="", rowAccountsDayEnd="", rowAccountsTotalExpenses="", rowAccountsTotalIncomes="";
	
	for(var i=0; i<accountLength; i++){
		dataLine.accounts.push([]);
		
		if(s==0){ accountsWholeStart.push(toEn(myJSONData["StartingAmounts"][i])); }
		else{ accountsWholeStart.push(toEn(myJSONData["days"][s-1]["endDayLeft"][i])); }
		
		accountsTotalExpenses.push(0);
		accountsTotalIncomes.push(0);
	}
	
	var transactionRowsOfTable="", transactionCounter=0;
	for (var day=s; day<=e; day++) {
		var year=myJSONData["days"][day]["year"],
			month=myJSONData["days"][day]["month"],
			theDay=myJSONData["days"][day]["day"];
		
		
		dataLine.labels.push(
			myJSONData["days"][day]["weekDay"]+" "+toFa(year+"/"+month+"/"+theDay)
		);
		// Set amount avilable at the end of each day for each account, required for plotting the 1st chart: Line Chart
		var j=accountLength;    while(j--){
			dataLine.accounts[j].push(
				myJSONData["days"][day]["endDayLeft"][j]
			);	
		}
		
		
		for (var transaction in myJSONData["days"][day]["transactions"]) {
			
			// for generating the table of all transactions between the two days s and e
			transactionCounter++;
			var accountRow="";
			for(var i=0 ; i<accountLength ; i++){
				var amount=Number(toEn(myJSONData["days"][day]["transactions"][transaction]["expenses"][i]));
				//updating the value of i'th "accountsTotalExpenses" or "accountsTotalIncomes"
				if(amount<0)	accountsTotalExpenses[i]+=amount;
				if(amount>0)	accountsTotalIncomes[i]+=amount;
				
				//demonstration
				accountRow+='<td>'+numberWithSeparators(toFa(amount))+'</td>';
			}
			transactionRowsOfTable+=
				'<tr>'		// for multicol table to work in firefox: style="display:block;"
					+'<td style="font-size:80%;">'+toFa(transactionCounter)+'</td><td style="text-align:center; font-size:85%;">'+toFa(year+"/"+month+"/"+theDay)+'</td><td style="text-align:right; font-size:85%;">'+myJSONData["days"][day]["transactions"][transaction]["title"]+'</td><td class="rotateHeader">'+myJSONData["days"][day]["transactions"][transaction]["class"]+'</td>'+accountRow
				+'</tr>';
			
			
			
			// populate the array "classesByDay"
			var aClass=myJSONData["days"][day]["transactions"][transaction]["class"];
			var sumRowClass=0;
			for(var i=0; i<accountLength; i++){
				sumRowClass+=toEn(myJSONData["days"][day]["transactions"][transaction]["expenses"][i]);
			}
			var l=classesByDay.length, check=0;
			for(var i=0; i<l ; i++){
				if(classesByDay[i]["name"]==aClass){
					var checkLabel=0;
					for(var date in classesByDay[i]["labels"]){
						if(classesByDay[i]["labels"][date][0]==year && classesByDay[i]["labels"][date][0]==month && classesByDay[i]["labels"][date][0]==theDay){
							//add the value to the previous value corresponding to that label
							classesByDay[i]["values"][date]+= -(sumRowClass);
							checkLabel=1;
							break;
						}
					}
					if(checkLabel==0){
						// add the label
						classesByDay[i].labels.push([year,month,theDay]);
						classesByDay[i].values.push(- sumRowClass);
					}
					check=1;
					break;
				}
			}
			//if(check==0 && aClass!="حقوق" && aClass!="هدیه +" && aClass!="قرض" && aClass!="جیب‌به‌جیب"){  // class "قرض" shall include all "قرض گرفتن", "قرض را پس دادن", "قرض دادن", و "قرض را پس گرفتن"
			if(check==0 && sumRowClass!=0){		// aClass!="جیب‌به‌جیب"
				classesByDay.push({"name":aClass, "labels":[], "values":[]});	//labels are [yyyy,m,d]
				classesByDay[l].labels.push([year,month,theDay]);
				classesByDay[l].values.push(- sumRowClass);	// the negative value of the spent expenses (a positive number) is stored
			}
			classesByDay.sort(function(a, b){return a["name"].localeCompare(b["name"])});
		}
	}
	
	
	// now having all the rows, let generate the table of all the transactions between the two days s and e
	var calculatedAmount;
	for(var i=0 ; i<accountLength ; i++){
		//multiply and divide by 10 to avoid round-off errors in JS (amounts in Tomans instead of Rials)
		accountsTotalExpenses[i]=Math.round( accountsTotalExpenses[i] * (-10) ) / 10;
		accountsTotalIncomes[i]=Math.round( accountsTotalIncomes[i] * 10 ) / 10;
		calculatedAmount=Math.round( ((accountsWholeStart[i]) + (accountsTotalIncomes[i])-(accountsTotalExpenses[i])) * 10 ) / 10;
		
		firstRowAccounts+='<th>'+accounts[i]+'</th>';
		rowAccountsDayStart+='<td>'+numberWithSeparators(accountsWholeStart[i])+'</td>';
		
		rowAccountsTotalExpenses+='<td>'+numberWithSeparators(accountsTotalExpenses[i])+'</td>';
		rowAccountsTotalIncomes+='<td>'+numberWithSeparators(accountsTotalIncomes[i])+'</td>';
		rowAccountsDayEnd+='<td>'+numberWithSeparators(calculatedAmount)+'</td>';
	}
	
	document.getElementById("reportTable").innerHTML=
		'<table class="transactionsDisplay" style="margin-top:5px;">'			// for multicol table to work in firefox:	"display:block; table-layout:fixed; "
			+'<tbody>'															// for multicol table to work in firefox:	style="display:block;"
				+'<tr style="font-size:80%;">'									// for multicol table to work in firefox:	"display:block;"
					+'<th class="rotateHeaderVertical"><div>ردیف</div></th><th style="text-align:center;">تاریخ تراکنش</th><th>عنوان تراکنش</th><th class="rotateHeader">گروه</th>'+firstRowAccounts
				+'</tr>'
				+'<tr style="font-size:80%;">'									// for multicol table to work in firefox:	"display:block;"
					+'<td colspan="4"  style="text-align:left; padding-left:10px; font-weight:bold;">موجودی:</td>'+rowAccountsDayStart
				+'</tr>'
				+transactionRowsOfTable
				+'<tr style="font-size:80%; background-color:rgb(225,225,225);">'									// for multicol table to work in firefox:	"display:block;"
					+'<td colspan="4"  style="text-align:left; padding-left:10px; font-weight:bold;">موجودی:</td>'+rowAccountsDayEnd
				+'</tr>'
				/*
				+'<tr style="font-size:80%; background-color: rgb(255,255,255);">'									// for multicol table to work in firefox:	"display:block;"
					+'<td colspan="4"  style="text-align:left; padding-left:10px; font-weight:bold;">مجموع درآمدها:</td>'+rowAccountsTotalIncomes
				+'</tr>'
				+'<tr style="font-size:80%; background-color: rgb(255,255,255);">'									// for multicol table to work in firefox:	"display:block;"
					+'<td colspan="4"  style="text-align:left; padding-left:10px; font-weight:bold;">مجموع هزینه‌کرد:</td>'+rowAccountsTotalExpenses
				+'</tr>'
				*/
			+'</tbody>'
		+'</table>';
		// in order to merge similar dates in the table into one cell spanning some rows, from https://stackoverflow.com/a/56588036	
		var headerCell = null,
			reportTableOfTransactions=document.getElementById("reportTable").firstChild;
		for(var row of reportTableOfTransactions.rows) {
			var firstCell = row.cells[1];
			if(headerCell === null  ||  firstCell.innerText !== headerCell.innerText) {
				headerCell = firstCell;
			}else{
				headerCell.rowSpan++;
				firstCell.remove();
			}
			headerCell.parentNode.style.borderTop='2px solid';
		}
		reportTableOfTransactions.rows[0].style.borderTop = reportTableOfTransactions.rows[1].style.borderTop = reportTableOfTransactions.rows[reportTableOfTransactions.rows.length - 1].style.borderTop='1px solid';
		
		
		
	//Next populate the array "classesByMonth" (used for BAR type chart) manipulating the array "classesByDay"
	for(var i in classesByDay){
		classesByMonth.datasets.push({"name":classesByDay[i].name,  "values":[]});
	}
	var yearFirst=myJSONData["days"][s]["year"],
		monthFirst=myJSONData["days"][s]["month"],
		l=myJSONData["days"].length,
		yearLast=myJSONData["days"][e]["year"],
		monthLast=myJSONData["days"][e]["month"];
	
	for(var y=yearFirst; y<=yearLast; y++){
		if(y==yearFirst && yearFirst<yearLast){
			//alert(1);
			for(var m=monthFirst; m<=12; m++){
				classesByMonth["labels"].push(toFa(y+"/"+m));
				
				var len=classesByMonth["labels"].length;
				for(var i in classesByDay){
					classesByMonth["datasets"][i]["values"].push(0);	// the initial value
					for(var date in classesByDay[i]["labels"]){
						if(classesByDay[i]["labels"][date][0]==y && classesByDay[i]["labels"][date][1]==m){
							classesByMonth["datasets"][i]["values"][len-1]+=classesByDay[i]["values"][date];
						}
					}
					classesByMonth["datasets"][i]["values"][len-1]=Math.round(classesByMonth["datasets"][i]["values"][len-1] * 10 ) / 10;	// for float number to be rounded to only 1 digit after the Point
				}
				
			}
		}else if(y<yearLast){
			//alert(2);
			for(var m=1; m<=12; m++){
				classesByMonth["labels"].push(toFa(y+"/"+m));
				
				var len=classesByMonth["labels"].length;
				for(var i in classesByDay){
					classesByMonth["datasets"][i]["values"].push(0);	// the initial value
					for(var date in classesByDay[i]["labels"]){
						if(classesByDay[i]["labels"][date][0]==y && classesByDay[i]["labels"][date][1]==m){
							classesByMonth["datasets"][i]["values"][len-1]+=classesByDay[i]["values"][date];
						}
					}
					classesByMonth["datasets"][i]["values"][len-1]=Math.round(classesByMonth["datasets"][i]["values"][len-1] * 10 ) / 10;	// for float number to be rounded to only 1 digit after the Point
				}
				
			}
		}else if(y==yearLast && y>yearFirst){
			//alert(3);
			for(var m=1; m<=monthLast; m++){
				classesByMonth["labels"].push(toFa(y+"/"+m));
				
				var len=classesByMonth["labels"].length;
				for(var i in classesByDay){
					classesByMonth["datasets"][i]["values"].push(0);	// the initial value
					for(var date in classesByDay[i]["labels"]){
						if(classesByDay[i]["labels"][date][0]==y && classesByDay[i]["labels"][date][1]==m){
							classesByMonth["datasets"][i]["values"][len-1]+=classesByDay[i]["values"][date];
						}
					}
					classesByMonth["datasets"][i]["values"][len-1]=Math.round(classesByMonth["datasets"][i]["values"][len-1] * 10 ) / 10;	// for float number to be rounded to only 1 digit after the Point
				}
				
			}
		}else{	// y=yearFirst=yearLast
			//alert(4);
			for(var m=monthFirst; m<=monthLast; m++){
				classesByMonth["labels"].push(toFa(y+"/"+m));
				
				var len=classesByMonth["labels"].length;
				for(var i in classesByDay){
					classesByMonth["datasets"][i]["values"].push(0);	// the initial value
					for(var date in classesByDay[i]["labels"]){
						if(classesByDay[i]["labels"][date][0]==y && classesByDay[i]["labels"][date][1]==m){
							classesByMonth["datasets"][i]["values"][len-1]+=classesByDay[i]["values"][date];
						}
					}
					classesByMonth["datasets"][i]["values"][len-1]=Math.round(classesByMonth["datasets"][i]["values"][len-1] * 10 ) / 10;	// for float number to be rounded to only 1 digit after the Point
				}
				
			}
		}
	}
	
	
	//Next populate the array "classesTotal" (used for BAR type chart) manipulating the array "classesByMonth"
	for(var i in classesByDay){
		var value=0;
		for(var val in classesByMonth["datasets"][i]["values"]){
			value+=classesByMonth["datasets"][i]["values"][val];
		}
		classesTotal.push({"name":classesByDay[i].name,  "value":Math.round(value * 10 ) / 10});
	}
	
	
	
	//Now draw the charts
	
	// Default font setting for all the texts in the canvas.
	Chart.defaults.font.family='Niloofar';
	Chart.defaults.font.size=12;
	Chart.defaults.color='black';
	
	var lineDatasets=[];
	for(var i=0; i<accountLength; i++){
		lineDatasets.push(
			{
				label: accounts[i],
				data: dataLine.accounts[i],
				fill: false,
				backgroundColor: color[i],
				borderColor: color[i],
				borderWidth: 2
			}
		);
	}
	var configLine = {
		type: 'line',
		data: {
			labels: dataLine.labels,
			datasets: lineDatasets,
		},
		options: {
			interaction: {
				//intersect: false,
				mode: 'index',		// if it was 'nearest' then it was not required for the mouse pointer to hover on the very 'points' to pop-up the tooltip
			},
			plugins: {
				title: {
					display: true,
					text: 'موجودی حساب‌ها در انتهای هر روز',		// if used as array ['موجودی حساب‌ها در انتهای هر روز',''], it'll be rendered on multiple lines
					font: {
						size: 18
					}
				},
				//legend: {
				//	position: 'bottom'
				//},
				tooltip: {
					callbacks: {
						label: function(tooltipItem) {
							return 'موجودی '+tooltipItem.dataset.label +': '+ numberWithSeparators(tooltipItem.parsed.y) + ' تومان';
						},
						footer: function(tooltipItems) {  // Use the footer callback to display the sum of the items showing in the tooltip
							var sum = 0;
							tooltipItems.forEach(function(tooltipItem) {
								sum += tooltipItem.parsed.y;
							});
							return 'مجموع موجودی: ' + numberWithSeparators(sum) +' تومان';
						}
					},
					footerFontStyle: 'normal',
					//rtl: true
				}
			},
			scales: {
				x: {
					title: {
						display: true,
						text: 'زمان',
						font: {
							size: 15
						}
					}
				},
				y: {
					title: {
						display: true,
						text: 'موجودی (تومان)',
						font: {
							size: 15
						}
					},
					suggestedMin: 0,	//نوشتم که اگر بابت قرض منفی شد هم نشان بدهد "min:0" این را به جای
					//max: dataMax+10,
					ticks: {
						callback: function(value, index, values) {
							return numberWithSeparators(value);//+' تومان';	
						}
					}
				}
			},
			maintainAspectRatio: false	// otherwise it will fill the whole page, with different diagrams residing one on another
		}
	};
	var ctxLine = document.getElementById('myChartLine').getContext('2d');
	if(chartLine){	// destory the old Line Chart, if any, so we can create a new Line Chart
		chartLine.destroy();
	}
	chartLine=new Chart(ctxLine, configLine);
	
	
	
	var barDatasets=[];
	for(var i in classesByMonth.datasets){
		barDatasets.push(
			{
				label:classesByMonth.datasets[i].name,
				data:classesByMonth.datasets[i].values,
				backgroundColor: color[i],
				borderColor: 'rgb(0,0,0)',
				borderWidth: 0.5
			}
		);
	}
	var configBar = {
		type: 'bar',
		data: {
			labels: classesByMonth.labels,
			datasets: barDatasets,
		},
		options: {
			interaction: {
				//intersect: false,
				mode: 'index',		// if it was 'nearest' then it was not required for the mouse pointer to hover on the very 'points' to pop-up the tooltip
			},
			plugins: {
				title: {
					display: true,
					text: 'بسته‌های هزینه‌ای به تفکیک ماه',		// if used as array ['بسته‌های هزینه‌ای به تفکیک ماه',''], it'll be rendered on multiple lines
					font: {
						size: 18
					}
				},
				legend: {
					position: 'bottom'
				},
				tooltip: {
					callbacks: {
						label: function(tooltipItem) {
							return tooltipItem.dataset.label +': '+ numberWithSeparators(tooltipItem.parsed.y) + ' تومان';
						}
					},
					//rtl: true
				}
			},
			scales: {
				x: {
					title: {
						display: true,
						text: 'زمان',
						font: {
							size: 15
						}
					},
					//stacked: true
				},
				y: {
					title: {
						display: true,
						text: 'هزینه (تومان)',
						font: {
							size: 15
						}
					},
					suggestedMin: 0,	//نوشتم که اگر بابت قرض منفی شد هم نشان بدهد "min:0" این را به جای
					//max: dataMax+10,
					ticks: {
						callback: function(value, index, values) {
							return numberWithSeparators(value);//+' تومان';	
						}
					},
					//stacked: true
				}
			},
			categoryPercentage: 1.0,
			barPercentage: 1.0,
			maintainAspectRatio: false	// otherwise it will fill the whole page, with different diagrams residing one on another
		}
	};
	var ctxBar = document.getElementById('myChartBar').getContext('2d');
	if(chartBar){	// destory the old Bar Chart, if any, so we can create a new Bar Chart
		chartBar.destroy();
	}
	chartBar=new Chart(ctxBar, configBar);
	
	
	
	
	var pieLabelsSpent=[], pieLabelsIncome=[], pieDataSpent=[], pieDataIncome=[];
	for(var i in classesTotal){
		if(classesTotal[i].value>=0){
			pieLabelsSpent.push(classesTotal[i].name);
			pieDataSpent.push(classesTotal[i].value);
		}else{
			/*
			alert("جمع هزینه‌ها برای گروه \""+classesTotal[i].name+"\" منفی به دست آمده است، به همین دلیل نمودار دایره‌ای قابل رسم نیست. لطفاً ورودی هزینه‌های خود را در این گروه وارسی نمایید.");
			document.getElementById('wrapperPieSpent').style.display = 'none';
			return false;
			*/
			pieLabelsIncome.push(classesTotal[i].name);
			pieDataIncome.push(-classesTotal[i].value);
		}
	}
	//document.getElementById('wrapperPieSpent').style.display = 'inline-block';
	var configPieSpent = {
		type: 'pie',
		data: {
			labels: pieLabelsSpent,
			datasets: [
				{
					label: '',
					data: pieDataSpent,
					backgroundColor: color,
					borderColor: 'rgba(0,0,0,0)',
					borderWidth: 1
				},
			]
		},
		options: {
			cutout: "30%",
			circumference: '180',
			rotation: '-90',
			plugins: {
				title: {
					display: true,
					text: 'هزینه‌ها در کل',		// if used as array ['هزینه‌ها در کل',''], it'll be rendered on multiple lines
					font: {
						size: 18
					}
				},
				legend: {
					position: 'bottom'
				},
				tooltip: {
					callbacks: {
						label: function(tooltipItem) {
							var value=Number(tooltipItem.formattedValue.replace(/,/g,"")),
								sum = 0,
								dataArr = tooltipItem.chart.data.datasets[0].data;
							dataArr.map(data => {
								sum += Number(data);
							});
							var percentage = '%' + (value * 100 / sum).toFixed(2);
							
							return [tooltipItem.label +': '+ numberWithSeparators(value) +' تومان', '('+ toFa(percentage) +' از مجموع '+numberWithSeparators(sum)+' تومان هزینه)'];
						}
					},
					//rtl: true
				}
			}
		}
	};
	var configPieIncome = {
		type: 'pie',
		data: {
			labels: pieLabelsIncome,
			datasets: [
				{
					label: '',
					data: pieDataIncome,
					backgroundColor: color,
					borderColor: 'rgba(0,0,0,0)',
					borderWidth: 1
				},
			]
		},
		options: {
			cutout: "30%",
			circumference: '180',
			rotation: '-90',
			plugins: {
				title: {
					display: true,
					text: 'درآمدها در کل',		// if used as array ['درآمدها در کل',''], it'll be rendered on multiple lines
					font: {
						size: 18
					}
				},
				legend: {
					position: 'bottom'
				},
				tooltip: {
					callbacks: {
						label: function(tooltipItem) {
							var value=Number(tooltipItem.formattedValue.replace(/,/g,"")),
								sum = 0,
								dataArr = tooltipItem.chart.data.datasets[0].data;
							dataArr.map(data => {
								sum += Number(data);
							});
							var percentage = '%' + (value * 100 / sum).toFixed(2);
							
							return [tooltipItem.label +': '+ numberWithSeparators(value) +' تومان', '('+ toFa(percentage) +' از مجموع '+numberWithSeparators(sum)+' تومان درآمد)'];
						}
					},
					//rtl: true
				}
			}
		}
	};
	var ctxPieSpent = document.getElementById('myChartPieSpent').getContext('2d');
	if(chartPieSpent){	// destory the old Pie Chart for SPENT items, if any, so we can create a new Pie Chart
		chartPieSpent.destroy();
	}
	chartPieSpent=new Chart(ctxPieSpent, configPieSpent);
	
	var ctxPieIncome = document.getElementById('myChartPieIncome').getContext('2d');
	if(chartPieIncome){	// destory the old Pie Chart for Income items, if any, so we can create a new Pie Chart
		chartPieIncome.destroy();
	}
	chartPieIncome=new Chart(ctxPieIncome, configPieIncome);
}

function inputReport(s,e){
	//alert(s+","+e);
	
	document.getElementById("fromDAY").value=toFa(myJSONData["days"][s]["day"]);
	document.getElementById("fromMONTH").value=toFa(myJSONData["days"][s]["month"]);
	document.getElementById("fromYEAR").value=toFa(myJSONData["days"][s]["year"]);
	
	document.getElementById("toDAY").value=toFa(myJSONData["days"][e]["day"]);
	document.getElementById("toMONTH").value=toFa(myJSONData["days"][e]["month"]);
	document.getElementById("toYEAR").value=toFa(myJSONData["days"][e]["year"]);
}
function okinputReport(){
	var	validatedFromDay=toEn(document.getElementById("fromDAY").value),
		validatedFromMonth=toEn(document.getElementById("fromMONTH").value),
		validatedFromYEAR=toEn(document.getElementById("fromYEAR").value),
		validatedtoDay=toEn(document.getElementById("toDAY").value),
		validatedtoMonth=toEn(document.getElementById("toMONTH").value),
		validatedtoYEAR=toEn(document.getElementById("toYEAR").value);
		
	if(	Number.isInteger(validatedFromDay) && validatedFromDay>=1 && validatedFromDay<=31 &&
		Number.isInteger(validatedFromMonth) && validatedFromMonth>=1 && validatedFromMonth<=12 &&
		Number.isInteger(validatedFromYEAR) && validatedFromYEAR>=0 &&
		Number.isInteger(validatedtoDay) && validatedtoDay>=1 && validatedtoDay<=31 &&
		Number.isInteger(validatedtoMonth) && validatedtoMonth>=1 && validatedtoMonth<=12 &&
		Number.isInteger(validatedtoYEAR) && validatedtoYEAR>=0){
		
		var validatedFromDayEx = (validatedFromDay<10) ? "0"+validatedFromDay : validatedFromDay;			//e.g. 5 -> 05
		var validatedtoDayEx = (validatedtoDay<10) ? "0"+validatedtoDay : validatedtoDay;					//e.g. 5 -> 05
		var validatedFromMonthEx = (validatedFromMonth<10) ? "0"+validatedFromMonth : validatedFromMonth;	//e.g. 5 -> 05
		var validatedtoMonthEx = (validatedtoMonth<10) ? "0"+validatedtoMonth : validatedtoMonth;			//e.g. 5 -> 05
		
		var startDate=Number(validatedFromYEAR+""+validatedFromMonthEx+""+validatedFromDayEx),
			endDate=Number(validatedtoYEAR+""+validatedtoMonthEx+""+validatedtoDayEx),
			startDateNum=0, endDateNum=myJSONData.days.length-1;
		
		for(var day=myJSONData.days.length-1; day>=0 ; day--){
			if(myJSONData["days"][day]["dateForSortAction"]>=startDate){
				startDateNum=day;
			}else{break;}
		}
		for(var day in myJSONData.days){
			if(myJSONData["days"][day]["dateForSortAction"]<=endDate){
				endDateNum=day;
			}else{break;}
		}
	}else{
		alert("لطفاً تاریخ‌ها را درست وارد نمایید.");
	}	
		
	generateReport(startDateNum,endDateNum);
}




//=============  PREVENT LEAVING THE PAGE AS THERE MIGHT BE UNSAVED DATA ==============//



//$(window).bind('beforeunload', function(){
//	return 'شما در حال ترک نرم‌افزار هستید، آیا تمایل دارید یادداشت‌های خود را در صورت تغییر ذخیره نمایید؟';
//});	
window.onbeforeunload = function() {
	return "توصیه بر ذخیره‌ی داده‌ها پیش از حروج از نرم‌افزار است ... آیا اطمینان دارید می‌خواهید از نرم‌افزار خارج شوید؟!";
}	
//window.addEventListener("beforeunload", function(event) {
//	event.returnValue = "شما در حال ترک نرم‌افزار هستید، آیا تمایل دارید داده‌های خود را در صورت تغییر ذخیره نمایید؟";
	//saveFunctioin();
//});
